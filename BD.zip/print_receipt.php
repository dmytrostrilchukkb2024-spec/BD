<?php
session_start();
require_once 'db.php';
if (!isset($_SESSION['admin_auth'])) { header("Location: login.php"); exit; }

$id = $_GET['id'] ?? 0;

// Отримуємо дані
$sql = "SELECT d.*, s.service_name, c.full_name as client, n.full_name as notary 
        FROM deals d 
        JOIN services s ON d.service_id = s.id_service 
        JOIN clients c ON d.client_id = c.id_client
        JOIN notaries n ON d.notary_id = n.id_notary
        WHERE id_deal = ?";
$stmt = $pdo->prepare($sql);
$stmt->execute([$id]);
$deal = $stmt->fetch();

if (!$deal) die("Чек не знайдено");

// Дані для QR-коду
$qrData = "ЧЕК #$id | Дата: {$deal['deal_date']} | Сума: {$deal['total_sum']} грн | Послуга: {$deal['service_name']}";
$qrUrl = "https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=" . urlencode($qrData);
?>

<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="UTF-8">
    <title>Чек #<?= $id ?></title>
    <style>
        body { background: #e5e5e5; display: flex; justify-content: center; padding-top: 50px; font-family: 'Courier New', Courier, monospace; }
        .receipt { background: #fff; width: 300px; padding: 20px; box-shadow: 0 0 10px rgba(0,0,0,0.1); position: relative; }
        .receipt::after { content: ""; background: linear-gradient(135deg, #e5e5e5 5px, transparent 0) 0 5px, linear-gradient(-135deg, #e5e5e5 5px, transparent 0) 0 5px; background-color: #fff; background-position: left bottom; background-repeat: repeat-x; background-size: 10px 10px; display: block; position: absolute; bottom: -10px; left: 0; width: 100%; height: 10px; }
        h2 { text-align: center; font-size: 1.2rem; margin-bottom: 5px; text-transform: uppercase; }
        .center { text-align: center; font-size: 0.8rem; color: #666; margin-bottom: 10px; }
        .line { border-top: 1px dashed #ccc; margin: 10px 0; }
        .row { display: flex; justify-content: space-between; font-size: 0.9rem; margin: 3px 0; }
        .total { font-size: 1.3rem; font-weight: bold; text-align: center; margin-top: 15px; }
        .qr-code { display: flex; justify-content: center; margin-top: 20px; }
        .print-btn { position: fixed; top: 20px; right: 20px; padding: 10px 20px; background: #333; color: white; border: none; cursor: pointer; border-radius: 5px; }

        @media print { body { background: white; padding: 0; } .receipt { box-shadow: none; width: 100%; } .print-btn { display: none; } }
    </style>
</head>
<body>

<button onclick="window.print()" class="print-btn">🖨 Друкувати</button>

<div class="receipt">
    <h2>Notary Office</h2>
    <div class="center">м. Київ, вул. Хрещатик, 1</div>
    <div class="center">Тел: +380 44 123 45 67</div>

    <div class="line"></div>

    <div class="row"><span>Квитанція №:</span> <span><?= $id ?></span></div>
    <div class="row"><span>Дата:</span> <span><?= date('d.m.Y H:i', strtotime($deal['deal_date'])) ?></span></div>
    <div class="row"><span>Нотаріус:</span> <span><?= mb_substr($deal['notary'], 0, 10) ?>...</span></div>

    <div class="line"></div>

    <div style="font-weight: bold; margin-bottom: 5px;"><?= $deal['service_name'] ?></div>
    <div class="row"><span>Клієнт:</span> <span><?= $deal['client'] ?></span></div>

    <div class="line"></div>

    <div class="total">ДО ОПЛАТИ: <?= number_format($deal['total_sum'], 2) ?> ₴</div>

    <div class="qr-code">
        <img src="<?= $qrUrl ?>" alt="QR">
    </div>

    <div class="center" style="margin-top: 15px; font-style: italic;">Дякуємо, що обрали нас!</div>
</div>

</body>
</html>
