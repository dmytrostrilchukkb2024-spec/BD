<?php
session_start();
require_once 'db.php';
if (!isset($_SESSION['admin_auth'])) { header("Location: login.php"); exit; }

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = trim($_POST['full_name']);
    $lic = trim($_POST['license_number']);
    $phone = trim($_POST['work_phone']);
    $cab = trim($_POST['cabinet_number']);

    if(!empty($name)) {
        // Використовуємо $pdo
        $sql = "INSERT INTO notaries (full_name, license_number, work_phone, cabinet_number) VALUES (?, ?, ?, ?)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$name, $lic, $phone, $cab]);
        header("Location: notaries.php");
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="uk" class="dark">
<head>
    <meta charset="UTF-8">
    <title>Новий нотаріус</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script> tailwind.config = { darkMode: 'class' } </script>
    <style> .glass { background: rgba(255, 255, 255, 0.05); backdrop-filter: blur(10px); border: 1px solid rgba(255, 255, 255, 0.1); } </style>
</head>
<body class="bg-slate-900 text-white flex items-center justify-center min-h-screen p-4">

<div class="glass w-full max-w-md p-8 rounded-3xl shadow-2xl border border-slate-700">
    <h2 class="text-3xl font-bold mb-6 text-center text-blue-400">⚖️ Додати нотаріуса</h2>

    <form method="POST" class="space-y-4">
        <input type="text" name="full_name" required placeholder="ПІБ Нотаріуса" class="w-full p-3 rounded-xl bg-slate-800 border border-slate-600 focus:border-blue-500 outline-none transition">
        <input type="text" name="license_number" required placeholder="№ Ліцензії" class="w-full p-3 rounded-xl bg-slate-800 border border-slate-600 focus:border-blue-500 outline-none transition">

        <div class="grid grid-cols-2 gap-4">
            <input type="text" name="work_phone" placeholder="Телефон" class="w-full p-3 rounded-xl bg-slate-800 border border-slate-600 focus:border-blue-500 outline-none transition">
            <input type="text" name="cabinet_number" placeholder="Кабінет" class="w-full p-3 rounded-xl bg-slate-800 border border-slate-600 focus:border-blue-500 outline-none transition">
        </div>

        <div class="flex gap-4 pt-4">
            <a href="notaries.php" class="flex-1 py-3 text-center rounded-xl bg-slate-700 hover:bg-slate-600 transition font-semibold">Назад</a>
            <button type="submit" class="flex-1 py-3 rounded-xl bg-blue-600 hover:bg-blue-500 font-bold shadow-lg shadow-blue-600/20">Додати</button>
        </div>
    </form>
</div>

</body>
</html>