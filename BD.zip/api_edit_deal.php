<?php
session_start();
require_once 'db.php';
header('Content-Type: application/json');

if (!isset($_SESSION['admin_auth'])) { echo json_encode(['success'=>false]); exit; }

$id = $_POST['id_deal'] ?? 0;
$sum = $_POST['total_sum'] ?? 0;
$status = $_POST['status'] ?? '';

if ($id && $status) {
    $stmt = $pdo->prepare("UPDATE deals SET total_sum = ?, status = ? WHERE id_deal = ?");
    $res = $stmt->execute([$sum, $status, $id]);
    echo json_encode(['success' => $res]);
} else {
    echo json_encode(['success' => false, 'message' => 'Неповні дані']);
}
