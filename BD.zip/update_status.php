<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['admin_auth'])) { header("Location: login.php"); exit; }

if (isset($_GET['id']) && isset($_GET['status'])) {
    $id = intval($_GET['id']);
    $status = $_GET['status'];

    // Дозволені статуси
    $allowed = ['Заплановано', 'В процесі', 'Завершено', 'Скасовано'];

    if (in_array($status, $allowed)) {
        $stmt = $pdo->prepare("UPDATE deals SET status = ? WHERE id_deal = ?");
        $stmt->execute([$status, $id]);
    }
}

// Повертаємо назад на канбан дошку
header("Location: kanban.php");
exit;
?>


update_user.php
<?php
require_once 'db.php';



Додаток 32.
// 2. Створюємо нового користувача
$new_login = "DmtStr";
$new_pass = "pass1234"; 

$sql = "INSERT INTO users (username, password, email) VALUES ('$new_login', '$new_pass', 'admin@example.com')";

if ($conn->query($sql) === TRUE) {
    echo "<h1>✅ Успішно!</h1>";
    echo "<p>Старий логін видалено.</p>";
    echo "<p>Новий логін: <b>$new_login</b></p>";
    echo "<p>Новий пароль: <b>$new_pass</b></p>";
    echo "<br><a href='login.php'>Перейти до входу</a>";
} else {
    echo "Помилка: " . $conn->error;
}
?>

Це скл

-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1
-- Час створення: Січ 04 2026 р., 16:09
-- Версія сервера: 10.4.32-MariaDB
-- Версія PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База даних: `notary_office`
--

-- --------------------------------------------------------

--
-- Структура таблиці `clients`
--

CREATE TABLE `clients` (
  `id_client` int(11) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `passport_series` varchar(5) DEFAULT NULL,
  `passport_number` varchar(10) NOT NULL,
  `address` varchar(200) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `doc_path` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп даних таблиці `clients`
--

INSERT INTO `clients` (`id_client`, `full_name`, `passport_series`, `passport_number`, `address`, `phone`, `doc_path`) VALUES
(2, 'Шевченко Ольга Павлівна', 'НС', '456456', 'м. Київ, вул. Лесі Українки, 10', '067-222-22-22', NULL),
(3, 'Кравчук Віталій Ігорович', 'КК', '789789', 'м. Львів, вул. Городоцька, 5', '063-333-33-33', NULL),
(4, 'Лисенко Тетяна Миколаївна', 'ТТ', '101101', 'м. Одеса, вул. Дерибасівська, 15', '099-444-44-44', NULL),
(5, 'Бойко Дмитро Володимирович', 'ОО', '202202', 'м. Харків, пл. Свободи, 7', '093-555-55-55', NULL),
(9, 'Кравець Денис Дмитрович', 'АВ', '534523', 'м. Дубно', '7984652345', NULL),
(10, 'Левчук Дмитро Ярославович', 'КВ', '456234', 'м. Львів', '+380 99 125 35 00', NULL),
(13, 'Стрільчук Дмитро Миколайович', 'АВ', '456234', 'м. Львів', '+380 99 125 35 00', NULL);

-- --------------------------------------------------------

--
-- Структура таблиці `deals`
--

CREATE TABLE `deals` (
  `id_deal` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `notary_id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL,
  `deal_date` datetime DEFAULT current_timestamp(),
  `total_sum` decimal(10,2) DEFAULT NULL,
  `status` enum('Заплановано','В процесі','Завершено','Скасовано') DEFAULT 'Заплановано'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп даних таблиці `deals`
--

INSERT INTO `deals` (`id_deal`, `client_id`, `notary_id`, `service_id`, `deal_date`, `total_sum`, `status`) VALUES
(2, 2, 2, 3, '2023-10-02 11:30:00', 1500.00, 'Завершено'),
(3, 3, 1, 2, '2023-10-03 09:15:00', 300.00, 'Заплановано'),
(4, 4, 3, 4, '2023-10-04 14:00:00', 5000.00, 'Завершено'),
(5, 5, 4, 5, '2023-10-05 16:45:00', 100.00, 'Завершено'),
(6, 5, 1, 3, '2025-12-07 20:06:30', 3000.00, 'В процесі'),
(7, 3, 4, 1, '2025-12-07 21:07:30', 800.00, 'В процесі');

-- --------------------------------------------------------

--
-- Структура таблиці `notaries`
--

CREATE TABLE `notaries` (
  `id_notary` int(11) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `license_number` varchar(20) NOT NULL,
  `work_phone` varchar(20) DEFAULT NULL,
  `cabinet_number` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп даних таблиці `notaries`
--

INSERT INTO `notaries` (`id_notary`, `full_name`, `license_number`, `work_phone`, `cabinet_number`) VALUES
(1, 'Петренко Іван Васильович', 'АА123456', '044-111-22-33', '101'),
(2, 'Коваленко Марія Іванівна', 'ВВ654321', '044-222-33-44', '102'),
(3, 'Сидоренко Олексій Петрович', 'СС987654', '044-333-44-55', '205'),
(4, 'Гончар Олена Сергіївна', 'DD112233', '044-444-55-66', '206'),
(5, 'Мельник Андрій Вікторович', 'EE445566', '044-555-66-77', '301');

-- --------------------------------------------------------

--
-- Структура таблиці `services`
--

CREATE TABLE `services` (
  `id_service` int(11) NOT NULL,
  `service_name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `duration_minutes` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп даних таблиці `services`
--

INSERT INTO `services` (`id_service`, `service_name`, `description`, `price`, `duration_minutes`) VALUES
(1, 'Оформлення довіреності', 'Довіреність на авто або нерухомість', 800.00, 30),
(2, 'Засвідчення підпису', 'Засвідчення справжності підпису на документах', 300.00, 15),
(3, 'Оформлення заповіту', 'Посвідчення заповіту з внесенням до реєстру', 1500.00, 60),
(4, 'Договір купівлі-продажу', 'Оформлення договору відчуження нерухомості', 5000.00, 120),
(5, 'Копія документа', 'Засвідчення вірності копії документа', 100.00, 10),
(6, 'Договір купівлі-продажу квартири', 'Повний супровід угоди, перевірка обтяжень, реєстрація права власності.', 5000.00, 120),
(7, 'Договір купівлі-продажу приватного будинку', '', 2000.00, 30);

-- --------------------------------------------------------

--
-- Структура таблиці `users`
--

CREATE TABLE `users` (
  `id_user` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(10) NOT NULL DEFAULT 'user'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп даних таблиці `users`
--

INSERT INTO `users` (`id_user`, `username`, `password`, `role`) VALUES
(1, 'DmtStr', 'pass123', 'admin'),
(2, 'User', 'securepass', 'user');

--
-- Індекси збережених таблиць
--

--
-- Індекси таблиці `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`id_client`);

--
-- Індекси таблиці `deals`
--
ALTER TABLE `deals`
  ADD PRIMARY KEY (`id_deal`),
  ADD KEY `client_id` (`client_id`),
  ADD KEY `notary_id` (`notary_id`),
  ADD KEY `service_id` (`service_id`);

--
-- Індекси таблиці `notaries`
--
ALTER TABLE `notaries`
  ADD PRIMARY KEY (`id_notary`),
  ADD UNIQUE KEY `license_number` (`license_number`);

--
-- Індекси таблиці `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`id_service`);

--
-- Індекси таблиці `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id_user`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT для збережених таблиць
--

--
-- AUTO_INCREMENT для таблиці `clients`
--
ALTER TABLE `clients`
  MODIFY `id_client` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT для таблиці `deals`
--
ALTER TABLE `deals`
  MODIFY `id_deal` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT для таблиці `notaries`
--
ALTER TABLE `notaries`
  MODIFY `id_notary` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT для таблиці `services`
--
ALTER TABLE `services`
  MODIFY `id_service` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT для таблиці `users`
--
ALTER TABLE `users`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Обмеження зовнішнього ключа збережених таблиць
--

--
-- Обмеження зовнішнього ключа таблиці `deals`
--
ALTER TABLE `deals`
  ADD CONSTRAINT `deals_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id_client`) ON DELETE CASCADE,
  ADD CONSTRAINT `deals_ibfk_2` FOREIGN KEY (`notary_id`) REFERENCES `notaries` (`id_notary`) ON DELETE CASCADE,
  ADD CONSTRAINT `deals_ibfk_3` FOREIGN KEY (`service_id`) REFERENCES `services` (`id_service`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
