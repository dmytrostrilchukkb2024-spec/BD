<?php
session_start();
require_once 'db.php';
if (!isset($_SESSION['admin_auth'])) { header("Location: login.php"); exit; }

// --- ЛОГІКА СОРТУВАННЯ ---

// 1. Отримуємо параметри
$sort = $_GET['sort'] ?? 'id_client';
$order = $_GET['order'] ?? 'DESC';

// 2. Список дозволених полів для сортування
$allowed_cols = ['id_client', 'full_name', 'passport_series', 'phone', 'address'];
$allowed_order = ['ASC', 'DESC'];

// Валідація
if (!in_array($sort, $allowed_cols)) {
    $sort = 'id_client';
}
if (!in_array($order, $allowed_order)) {
    $order = 'DESC';
}

// 3. Формуємо SQL запит
if ($sort === 'passport_series') {
    $sql_order = "passport_series {$order}, passport_number {$order}";
} else {
    $sql_order = "{$sort} {$order}";
}

$sql = "SELECT * FROM clients ORDER BY {$sql_order}";
$stmt = $pdo->query($sql);
$rows = $stmt->fetchAll();

// Функція для генерації посилань сортування
function sortLink($col, $label, $currentSort, $currentOrder) {
    $nextOrder = ($currentSort === $col && $currentOrder === 'ASC') ? 'DESC' : 'ASC';
    $icon = '';
    if ($currentSort === $col) {
        $icon = ($currentOrder === 'ASC') ? ' 🔼' : ' 🔽';
    }
    return "<a href='?sort=$col&order=$nextOrder' class='hover:text-blue-500 transition'>$label$icon</a>";
}
?>
<!DOCTYPE html>
<html lang="uk" class="dark">
<head>
    <meta charset="UTF-8">
    <title>Клієнти</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script> tailwind.config = { darkMode: 'class' } </script>
</head>
<body class="bg-gray-100 dark:bg-slate-900 text-slate-800 dark:text-slate-100 flex h-screen overflow-hidden font-sans">

<?php include 'sidebar_template.php'; ?>

<main class="flex-1 flex flex-col relative h-full">
    <header class="h-24 bg-white/80 dark:bg-slate-800/80 backdrop-blur border-b border-gray-200 dark:border-slate-700 flex items-center justify-between px-8 sticky top-0 z-10">
        <h2 class="text-2xl font-bold">👥 База клієнтів</h2>
        <div class="flex gap-4">
             <input type="text" id="searchInput" placeholder="Швидкий пошук..." class="p-2 rounded-lg bg-gray-100 dark:bg-slate-700 border border-gray-300 dark:border-slate-600 outline-none focus:ring-2 focus:ring-blue-500">
             <a href="add_client.php" class="px-4 py-2 bg-green-600 hover:bg-green-700 text-white font-semibold rounded-xl shadow transition">+ Новий клієнт</a>
        </div>
    </header>

    <div class="p-8 flex-1 overflow-y-auto">
        <div class="bg-white dark:bg-slate-800 rounded-2xl shadow-xl border border-gray-200 dark:border-slate-700 overflow-hidden">
            <table class="w-full text-left border-collapse">
                <thead>
                    <tr class="bg-gray-50 dark:bg-slate-700/50 text-gray-500 dark:text-gray-400 text-xs uppercase font-bold">
                        <th class="px-6 py-4"><?= sortLink('id_client', 'ID', $sort, $order) ?></th>
                        <th class="px-6 py-4"><?= sortLink('full_name', 'ПІБ Клієнта', $sort, $order) ?></th>
                        <th class="px-6 py-4"><?= sortLink('passport_series', 'Паспорт', $sort, $order) ?></th>
                        <th class="px-6 py-4"><?= sortLink('phone', 'Телефон', $sort, $order) ?></th>
                        <th class="px-6 py-4"><?= sortLink('address', 'Адреса', $sort, $order) ?></th>
                        <th class="px-6 py-4 text-center">Дії</th>
                    </tr>
                </thead>
                <tbody id="clientsTableBody" class="divide-y divide-gray-100 dark:divide-slate-700">
                <?php foreach($rows as $r): ?>
                    <tr class="hover:bg-gray-50 dark:hover:bg-slate-700/30 transition">
                        <td class="px-6 py-4 font-mono text-xs text-gray-400">#<?= $r['id_client'] ?></td>
                        <td class="px-6 py-4 font-bold text-slate-700 dark:text-slate-200"><?= htmlspecialchars($r['full_name']) ?></td>
                        <td class="px-6 py-4 text-sm"><?= $r['passport_series'] ?> <?= $r['passport_number'] ?></td>
                        <td class="px-6 py-4 text-sm"><?= htmlspecialchars($r['phone']) ?></td>
                        <td class="px-6 py-4 text-sm italic text-gray-500 dark:text-gray-400"><?= htmlspecialchars($r['address']) ?></td>
                        <td class="px-6 py-4 flex justify-center gap-2">
                            <a href="edit.php?type=client&id=<?= $r['id_client'] ?>"
                               class="px-3 py-1 text-sm bg-blue-100 text-blue-600 rounded-lg hover:bg-blue-200 dark:bg-blue-900 dark:text-blue-300 dark:hover:bg-blue-800 transition">
                                Ред.
                            </a>
                            <a href="delete.php?id=<?= $r['id_client'] ?>&table=clients&col=id_client"
                               class="px-3 py-1 text-sm bg-red-100 text-red-600 rounded-lg hover:bg-red-200 dark:bg-red-900 dark:text-red-300 dark:hover:bg-red-800 transition"
                               onclick="return confirm('Видалити цього клієнта?')">
                                Вид.
                            </a>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</main>

<script>
    // Простий JS для пошуку на сторінці
    document.getElementById('searchInput')?.addEventListener('keyup', function() {
        let searchValue = this.value.toLowerCase();
        let rows = document.querySelectorAll('#clientsTableBody tr');

        rows.forEach(row => {
            let text = row.innerText.toLowerCase();
            row.style.display = text.includes(searchValue) ? '' : 'none';
        });
    });

    // Темна тема
    if (localStorage.getItem('theme') === 'dark' || (!('theme' in localStorage) && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
        document.documentElement.classList.add('dark');
    } else {
        document.documentElement.classList.remove('dark');
    }
</script>

</body>
</html>
