<aside class="w-64 bg-white dark:bg-slate-800 border-r border-gray-200 dark:border-slate-700 flex flex-col shadow-xl z-20 transition-colors duration-300 flex-shrink-0 hidden md:flex h-screen sticky top-0">
    <div class="h-20 flex items-center justify-center border-b border-gray-200 dark:border-slate-700 flex-shrink-0">
        <h1 class="text-2xl font-extrabold bg-clip-text text-transparent bg-gradient-to-r from-blue-500 to-purple-600 cursor-default">
            NOTARY CRM
        </h1>
    </div>

    <nav class="flex-1 px-4 py-6 space-y-2 overflow-y-auto">
        <?php
        $current_page = basename($_SERVER['PHP_SELF']);
        $menu_items = [
            'board.php' => ['icon' => '📊', 'label' => 'Головна'],
            'kanban.php' => ['icon' => '📋', 'label' => 'Угоди'],
            'clients.php' => ['icon' => '👥', 'label' => 'Клієнти'],
            'services.php' => ['icon' => '📝', 'label' => 'Послуги'],
            'notaries.php' => ['icon' => '⚖️', 'label' => 'Нотаріуси'],
            'stats.php' => ['icon' => '📈', 'label' => 'Статистика'],
            'settings.php' => ['icon' => '⚙️', 'label' => 'Налаштування'],
            'deals_search.php' => ['icon' => '🔍', 'label' => 'Пошук'],
        ];

        foreach ($menu_items as $file => $item) {
            $active = ($current_page == $file)
                ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/30'
                : 'text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-slate-700';
            
            echo "<a href='$file' class='flex items-center px-4 py-3 rounded-xl transition transform hover:scale-105 $active'>
                    <span class='text-xl mr-3'>{$item['icon']}</span>
                    <span class='font-medium'>{$item['label']}</span>
                  </a>";
        }
        ?>
    </nav>

    <div class="p-4 border-t border-gray-200 dark:border-slate-700 space-y-2">
        <button id="theme-toggle" class="w-full flex items-center justify-center gap-2 p-3 bg-gray-100 dark:bg-slate-700 rounded-xl hover:bg-gray-200 dark:hover:bg-slate-600 transition">
            <span id="theme-icon-sun" class="hidden text-yellow-400">☀️ Світла</span>
            <span id="theme-icon-moon" class="text-blue-400">🌙 Темна</span>
        </button>

        <a href="logout.php" class="flex items-center justify-center gap-2 p-3 text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-xl transition font-bold">
            🚪 Вийти
        </a>
    </div>
</aside>

<script>
    // --- ЛОГІКА ТЕМИ ---
    const themeToggleBtn = document.getElementById('theme-toggle');
    const sunIcon = document.getElementById('theme-icon-sun');
    const moonIcon = document.getElementById('theme-icon-moon');
    const htmlEl = document.documentElement;

    function updateThemeIcons() {
        if (htmlEl.classList.contains('dark')) {
            sunIcon.classList.remove('hidden');
            moonIcon.classList.add('hidden');
        } else {
            sunIcon.classList.add('hidden');
            moonIcon.classList.remove('hidden');
        }
    }

    if (localStorage.getItem('theme') === 'dark' || (!('theme' in localStorage) && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
        htmlEl.classList.add('dark');
    } else {
        htmlEl.classList.remove('dark');
    }
    updateThemeIcons();

    themeToggleBtn.addEventListener('click', function() {
        if (htmlEl.classList.contains('dark')) {
            htmlEl.classList.remove('dark');
            localStorage.setItem('theme', 'light');
        } else {
            htmlEl.classList.add('dark');
            localStorage.setItem('theme', 'dark');
        }
        updateThemeIcons();
    });
</script>
