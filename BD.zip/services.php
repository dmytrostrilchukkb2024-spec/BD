<?php
session_start();
require_once 'db.php';
if (!isset($_SESSION['admin_auth'])) { header("Location: login.php"); exit; }

// --- ЛОГІКА СОРТУВАННЯ ---

// 1. Отримуємо поточний параметр сортування та напрямок
$sort = $_GET['sort'] ?? 'id_service'; // Сортуємо за ID за замовчуванням
$order = $_GET['order'] ?? 'DESC';

// 2. Перевірка дозволених колонок та напрямку (для безпеки)
// Додано 'service_name' та 'description' для сортування
$allowed_cols = ['id_service', 'service_name', 'description', 'price', 'duration_minutes'];
$allowed_order = ['ASC', 'DESC'];

if (!in_array($sort, $allowed_cols)) {
    $sort = 'id_service';
}
if (!in_array($order, $allowed_order)) {
    $order = 'DESC';
}

// 3. Формуємо SQL запит
$sql = "SELECT * FROM services ORDER BY {$sort} {$order}";
$rows = $pdo->query($sql)->fetchAll();


// --- ЛОГІКА ДОДАВАННЯ ПОСЛУГИ ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_service'])) {
    $name = trim($_POST['service_name']);
    $price = trim($_POST['price']);
    $duration = trim($_POST['duration_minutes']);
    $desc = trim($_POST['description']);

    if(!empty($name)) {
        $stmt = $pdo->prepare("INSERT INTO services (service_name, price, duration_minutes, description) VALUES (?, ?, ?, ?)");
        $stmt->execute([$name, $price, $duration, $desc]);
        header("Location: services.php");
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="uk" class="dark">
<head>
    <meta charset="UTF-8">
    <title>Послуги | Admin Panel</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script> tailwind.config = { darkMode: 'class' } </script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <script>
        if (localStorage.getItem('theme') === 'dark' || (!('theme' in localStorage) && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
            document.documentElement.classList.add('dark');
        } else {
            document.documentElement.classList.remove('dark');
        }
    </script>
</head>
<body class="bg-gray-100 dark:bg-slate-900 text-slate-800 dark:text-slate-100 flex h-screen overflow-hidden font-sans">

<?php include 'sidebar_template.php'; ?>

<main class="flex-1 flex flex-col relative h-full">
    <header class="h-24 bg-white/80 dark:bg-slate-800/80 backdrop-blur border-b border-gray-200 dark:border-slate-700 flex items-center px-8 sticky top-0 z-10">
        <h2 class="text-2xl font-bold flex items-center gap-2">📝 Управління послугами</h2>
    </header>

    <div class="p-8 flex-1 overflow-y-auto">

        <div class="bg-white dark:bg-slate-800 p-6 rounded-2xl shadow-xl mb-8 border border-gray-100 dark:border-slate-700">
            <h3 class="text-xl font-semibold mb-4 text-green-600 dark:text-green-400">Додати нову послугу</h3>
            <form method="POST" class="grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
                <div class="md:col-span-2">
                    <label class="block text-xs uppercase font-bold text-gray-500 dark:text-gray-400 mb-1">Назва послуги</label>
                    <input type="text" name="service_name" required placeholder="Довіреність на авто"
                           class="w-full p-3 rounded-xl bg-gray-50 dark:bg-slate-700 border border-gray-300 dark:border-slate-600 focus:ring-2 focus:ring-green-500 outline-none transition">
                </div>
                <div>
                    <label class="block text-xs uppercase font-bold text-gray-500 dark:text-gray-400 mb-1">Ціна (грн)</label>
                    <input type="number" step="1" name="price" required placeholder="800"
                           class="w-full p-3 rounded-xl bg-gray-50 dark:bg-slate-700 border border-gray-300 dark:border-slate-600 focus:ring-2 focus:ring-green-500 outline-none transition">
                </div>
                <div>
                    <label class="block text-xs uppercase font-bold text-gray-500 dark:text-gray-400 mb-1">Тривалість (хв)</label>
                    <input type="number" name="duration_minutes" placeholder="30"
                           class="w-full p-3 rounded-xl bg-gray-50 dark:bg-slate-700 border border-gray-300 dark:border-slate-600 focus:ring-2 focus:ring-green-500 outline-none transition">
                </div>
                <div class="md:col-span-3">
                    <label class="block text-xs uppercase font-bold text-gray-500 dark:text-gray-400 mb-1">Опис</label>
                    <input type="text" name="description" placeholder="Короткий опис послуги..."
                           class="w-full p-3 rounded-xl bg-gray-50 dark:bg-slate-700 border border-gray-300 dark:border-slate-600 focus:ring-2 focus:ring-green-500 outline-none transition">
                </div>
                <div>
                    <button type="submit" name="add_service"
                            class="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-3 rounded-xl shadow-lg shadow-green-500/30 transition transform hover:scale-105">
                        ➕ Додати
                    </button>
                </div>
            </form>
        </div>

        <div class="bg-white dark:bg-slate-800 rounded-2xl shadow-xl overflow-hidden border border-gray-100 dark:border-slate-700">
            <table class="w-full text-left border-collapse">
                <thead class="bg-gray-50 dark:bg-slate-700/50">
                    <tr>
                        <th class="px-6 py-4 text-xs uppercase font-bold text-gray-500 dark:text-gray-400">
                            <a href="?sort=service_name&order=<?= $order === 'ASC' ? 'DESC' : 'ASC' ?>" class="hover:text-blue-500 flex items-center gap-1">
                                Назва <?= $sort === 'service_name' ? ($order === 'ASC' ? '↑' : '↓') : '' ?>
                            </a>
                        </th>
                        <th class="px-6 py-4 text-xs uppercase font-bold text-gray-500 dark:text-gray-400">Опис</th>
                        <th class="px-6 py-4 text-xs uppercase font-bold text-gray-500 dark:text-gray-400">
                            <a href="?sort=price&order=<?= $order === 'ASC' ? 'DESC' : 'ASC' ?>" class="hover:text-blue-500 flex items-center gap-1 text-center justify-center">
                                Ціна / Час <?= $sort === 'price' ? ($order === 'ASC' ? '↑' : '↓') : '' ?>
                            </a>
                        </th>
                        <th class="px-6 py-4 text-xs uppercase font-bold text-gray-500 dark:text-gray-400 text-center">Дії</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100 dark:divide-slate-700">
                    <?php foreach ($rows as $r): ?>
                    <tr class="hover:bg-gray-50/50 dark:hover:bg-slate-700/30 transition">
                        <td class="px-6 py-4 font-semibold text-gray-900 dark:text-white">
                            <?= htmlspecialchars($r['service_name']) ?>
                        </td>
                        <td class="px-6 py-4 text-sm text-gray-500 dark:text-gray-400 italic">
                            <?= htmlspecialchars($r['description']) ?>
                        </td>
                        <td class="px-6 py-4 text-center">
                            <div class="font-bold text-green-600 dark:text-green-400">
                                <?= number_format($r['price'], 0, '.', ' ') ?> ₴
                            </div>
                            <div class="text-xs text-gray-500 dark:text-gray-400 mt-1">
                                ⏱ <?= $r['duration_minutes'] ?> хв
                            </div>
                        </td>
                        <td class="px-6 py-4 flex justify-center gap-2">
                            <a href="edit.php?type=service&id=<?= $r['id_service'] ?>"
                               class="px-3 py-1 text-sm bg-blue-100 text-blue-600 rounded-lg hover:bg-blue-200 dark:bg-blue-900 dark:text-blue-300 dark:hover:bg-blue-800 transition">
                                Редагувати
                            </a>
                            <a href="delete.php?id=<?= $r['id_service'] ?>&table=services&col=id_service"
                               class="px-3 py-1 text-sm bg-red-100 text-red-600 rounded-lg hover:bg-red-200 dark:bg-red-900 dark:text-red-300 dark:hover:bg-red-800 transition"
                               onclick="return confirm('Ви впевнені, що хочете видалити послугу?')">
                                Видалити
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</main>
</body>
</html>
