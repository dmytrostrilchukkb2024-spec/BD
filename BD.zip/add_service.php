<?php
session_start();
require_once 'db.php';
if (!isset($_SESSION['admin_auth'])) { header("Location: login.php"); exit; }

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = trim($_POST['service_name']);
    $desc = trim($_POST['description']);
    $price = trim($_POST['price']);
    $dur = trim($_POST['duration_minutes']);

    if(!empty($name)) {
        $sql = "INSERT INTO services (service_name, description, price, duration_minutes) VALUES (?, ?, ?, ?)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$name, $desc, $price, $dur]);
        header("Location: services.php");
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="uk" class="dark">
<head>
    <meta charset="UTF-8">
    <title>Нова послуга</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script> tailwind.config = { darkMode: 'class' } </script>
    <style> .glass { background: rgba(255, 255, 255, 0.05); backdrop-filter: blur(10px); border: 1px solid rgba(255, 255, 255, 0.1); } </style>
</head>
<body class="bg-gray-900 text-white flex items-center justify-center min-h-screen p-4">

<div class="glass w-full max-w-lg p-8 rounded-3xl shadow-2xl">
    <h2 class="text-3xl font-bold mb-6 text-center text-green-400">📝 Нова послуга</h2>

    <form method="POST" class="space-y-4">
        <div>
            <label class="block text-xs font-bold uppercase text-gray-400 mb-1">Назва</label>
            <input type="text" name="service_name" required class="w-full p-3 rounded-xl bg-gray-800 border border-gray-700 focus:border-green-500 outline-none transition">
        </div>

        <div class="grid grid-cols-2 gap-4">
            <div>
                <label class="block text-xs font-bold uppercase text-gray-400 mb-1">Ціна (грн)</label>
                <input type="number" name="price" step="0.01" required class="w-full p-3 rounded-xl bg-gray-800 border border-gray-700 focus:border-green-500 outline-none transition">
            </div>
            <div>
                <label class="block text-xs font-bold uppercase text-gray-400 mb-1">Час (хв)</label>
                <input type="number" name="duration_minutes" class="w-full p-3 rounded-xl bg-gray-800 border border-gray-700 focus:border-green-500 outline-none transition">
            </div>
        </div>

        <div>
            <label class="block text-xs font-bold uppercase text-gray-400 mb-1">Опис</label>
            <textarea name="description" rows="3" class="w-full p-3 rounded-xl bg-gray-800 border border-gray-700 focus:border-green-500 outline-none transition"></textarea>
        </div>

        <div class="flex gap-4 pt-4">
            <a href="services.php" class="flex-1 py-3 text-center rounded-xl bg-gray-700 hover:bg-gray-600 transition font-semibold">Скасувати</a>
            <button type="submit" class="flex-1 py-3 rounded-xl bg-green-600 hover:bg-green-500 font-bold shadow-lg shadow-green-600/20">Створити</button>
        </div>
    </form>
</div>

</body>
</html>
