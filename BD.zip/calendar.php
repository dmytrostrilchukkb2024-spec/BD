<?php
session_start();
require_once 'db.php';
if (!isset($_SESSION['admin_auth'])) { header("Location: login.php"); exit; }

// --- ЛОГІКА СОРТУВАННЯ ---

// 1. Отримуємо параметри сортування
$sort = $_GET['sort'] ?? 'd.deal_date'; // За датою за замовчуванням
$order = $_GET['order'] ?? 'DESC';

// 2. Перевірка дозволених колонок та напрямку (для безпеки)
$allowed_cols = ['d.deal_date', 'd.total_sum', 'd.status', 'c.full_name', 's.service_name'];
$allowed_order = ['ASC', 'DESC'];

if (!in_array($sort, $allowed_cols)) {
    $sort = 'd.deal_date';
}
if (!in_array($order, $allowed_order)) {
    $order = 'DESC';
}

// 3. Формуємо Складений SQL запит
$sql = "SELECT d.*, c.full_name, s.service_name 
        FROM deals d
        LEFT JOIN clients c ON d.client_id = c.id_client
        LEFT JOIN services s ON d.service_id = s.id_service
        ORDER BY {$sort} {$order}";
$deals = $pdo->query($sql)->fetchAll();


// Функція для відображення назви колонки у зрозумілому вигляді
function get_sort_label($col_name) {
    $map = [
            'd.deal_date' => 'Дата/Час',
            'd.total_sum' => 'Сума',
            'd.status' => 'Статус',
            'c.full_name' => 'Клієнт',
            's.service_name' => 'Послуга'
    ];
    return $map[$col_name] ?? 'Невідомо';
}

?>

<!DOCTYPE html>
<html lang="uk" class="dark">
<head>
    <meta charset="UTF-8">
    <title>Календар угод</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script> tailwind.config = { darkMode: 'class' } </script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <script>
        if (localStorage.getItem('theme') === 'dark' || (!('theme' in localStorage) && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
            document.documentElement.classList.add('dark');
        } else {
            document.documentElement.classList.remove('dark');
        }
    </script>

    <style>
        /* Основні стилі для timeline-card */
        .timeline-container {
            display: flex;
            flex-direction: column;
            gap: 1.5rem;
            padding: 1rem;
        }
        .timeline-card {
            display: flex;
            align-items: center;
            background-color: #fff;
            border-radius: 1rem;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -2px rgba(0, 0, 0, 0.1);
            padding: 1.5rem;
            border-left: 6px solid #e5e7eb;
            transition: all 0.2s;
        }
        .dark .timeline-card {
            background-color: #1e293b;
            box-shadow: 0 4px 6px -1px rgba(255, 255, 255, 0.05), 0 2px 4px -2px rgba(255, 255, 255, 0.05);
            border-left-color: #475569;
        }
        .timeline-card:hover {
            transform: translateY(-2px);
        }

        /* Кольори для статусів */
        .status-Заплановано { border-left-color: #f59e0b; } /* Amber - Помаранчевий */
        .status-В_процесі { border-left-color: #3b82f6; } /* Blue - Синій */
        .status-Завершено { border-left-color: #10b981; } /* Emerald - Зелений */

        .dark .status-Заплановано { border-left-color: #fcd34d; }
        .dark .status-В_процесі { border-left-color: #60a5fa; }
        .dark .status-Завершено { border-left-color: #34d399; }

        .date-box {
            background: #f3f4f6;
            color: #1f2937;
            padding: 0.5rem 1rem;
            border-radius: 0.5rem;
            font-weight: 700;
            text-align: center;
            font-size: 1.125rem;
            line-height: 1.25;
            flex-shrink: 0;
            margin-right: 1.5rem;
        }
        .dark .date-box {
            background: #334155;
            color: #f1f5f9;
        }
        .time-box {
            display: block;
            font-size: 0.75rem;
            font-weight: 500;
            color: #6b7280;
        }
        .dark .time-box {
            color: #94a3b8;
        }
        .info-box h4 {
            font-size: 1.25rem;
            font-weight: 600;
            margin-bottom: 0.5rem;
            color: #1f2937;
        }
        .dark .info-box h4 {
            color: #f1f5f9;
        }
        .info-box div {
            font-size: 0.9rem;
            color: #6b7280;
        }
        .dark .info-box div {
            color: #94a3b8;
        }
        .price-tag {
            margin-left: auto;
            font-size: 1.5rem;
            font-weight: 700;
            color: #10b981; /* Emerald */
            flex-shrink: 0;
        }
        .dark .price-tag {
            color: #34d399;
        }
        .actions-box {
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
            margin-left: 1.5rem;
            flex-shrink: 0;
            align-items: center;
        }
        .btn-link {
            padding: 0.5rem 0.75rem;
            border-radius: 0.5rem;
            font-size: 0.75rem;
            font-weight: 600;
            transition: background-color 0.15s;
        }
        .btn-print {
            background-color: #dbeafe;
            color: #2563eb;
        }
        .dark .btn-print {
            background-color: #1e3a8a;
            color: #93c5fd;
        }
        .btn-print:hover { background-color: #bfdbfe; }
        .dark .btn-print:hover { background-color: #25447a; }

        .btn-del {
            background-color: #fee2e2;
            color: #dc2626;
        }
        .dark .btn-del {
            background-color: #7f1d1d;
            color: #fca5a5;
        }
        .btn-del:hover { background-color: #fecaca; }
        .dark .btn-del:hover { background-color: #8c2a2a; }

        /* Стилі для заголовків сортування */
        .sort-header {
            padding: 0.5rem 0.75rem; /* Зменшив горизонтальний паддінг */
            font-weight: 600;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 0.25rem;
            color: #6b7280;
            border-radius: 0.75rem;
            transition: all 0.2s;
        }
        .dark .sort-header {
            color: #94a3b8;
        }
        .sort-header:hover {
            background-color: #e5e7eb;
            color: #3b82f6;
        }
        .dark .sort-header:hover {
            background-color: #334155;
            color: #93c5fd;
        }
        .sort-header.active {
            background-color: #bfdbfe;
            color: #1d4ed8;
            box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.06);
        }
        .dark .sort-header.active {
            background-color: #1e3a8a;
            color: #93c5fd;
        }
    </style>
</head>
<body class="bg-gray-100 dark:bg-slate-900 text-slate-800 dark:text-slate-100 flex h-screen overflow-hidden font-sans">

<?php include 'sidebar_template.php'; ?>

<main class="flex-1 flex flex-col relative h-full">
    <header class="h-24 bg-white/80 dark:bg-slate-800/80 backdrop-blur border-b border-gray-200 dark:border-slate-700 flex items-center px-8 sticky top-0 z-10">
        <h2 class="text-2xl font-bold flex items-center gap-2">📅 Календар угод</h2>
        <a href="create.php" class="ml-auto px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-xl shadow transition">
            + Створити угоду
        </a>
    </header>

    <div class="p-8 flex-1 overflow-y-auto">
        <div class="flex flex-wrap gap-2 mb-6 bg-white dark:bg-slate-800 p-4 rounded-xl shadow-md border border-gray-200 dark:border-slate-700">
            <span class="text-sm font-semibold text-gray-500 dark:text-gray-400 p-2 flex items-center">Сортувати за:</span>

            <?php
            // Функція для генерації посилання сортування
            function get_sort_link_html($col_name, $current_sort, $current_order) {
                $is_active = $current_sort === $col_name;
                // Якщо колонка активна і поточний порядок ASC, наступний DESC, і навпаки. Інакше - ASC (або DESC для дати)
                $default_order = ($col_name === 'd.deal_date') ? 'DESC' : 'ASC';
                $next_order = ($is_active && $current_order === 'ASC') ? 'DESC' : 'ASC';
                $icon = $is_active ? ($current_order === 'ASC' ? '▲' : '▼') : '';
                $class = 'sort-header ' . ($is_active ? 'active' : '');
                $label = get_sort_label($col_name);

                return "<a href=\"?sort={$col_name}&order={$next_order}\" class=\"{$class}\">{$label} <span class=\"text-xs\">{$icon}</span></a>";
            }
            ?>

            <?= get_sort_link_html('d.deal_date', $sort, $order) ?>
            <?= get_sort_link_html('d.status', $sort, $order) ?>
            <?= get_sort_link_html('d.total_sum', $sort, $order) ?>
            <?= get_sort_link_html('c.full_name', $sort, $order) ?>
            <?= get_sort_link_html('s.service_name', $sort, $order) ?>

        </div>
        <div class="timeline-container">
            <?php if(empty($deals)): ?>
                <p class="text-center py-10 text-gray-500 dark:text-gray-400">Угод поки немає.</p>
            <?php endif; ?>

            <?php foreach($deals as $d):
                // Форматуємо дату
                $ts = strtotime($d['deal_date']);
                $dateStr = date('d.m', $ts);
                $timeStr = date('H:i', $ts);
                // Заміна пробілу на підкреслення для CSS класу статусу
                $statusClass = 'status-' . str_replace(' ', '_', $d['status']);
                ?>

                <div class="timeline-card <?= $statusClass ?>">
                    <div class="date-box">
                        <?= $dateStr ?>
                        <span class="time-box"><?= $timeStr ?></span>
                    </div>
                    <div class="info-box flex-1">
                        <h4><?= htmlspecialchars($d['service_name']) ?></h4>
                        <div>
                            👤 Клієнт: <b><?= htmlspecialchars($d['full_name']) ?></b>
                        </div>
                        <div style="margin-top:5px;">
                            Статус:
                            <span class="px-2 py-0.5 rounded-md font-medium text-xs
                                <?= $d['status'] === 'Завершено' ? 'bg-green-100 dark:bg-green-900 text-green-700 dark:text-green-300' :
                                    ($d['status'] === 'В процесі' ? 'bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300' :
                                            'bg-amber-100 dark:bg-amber-900 text-amber-700 dark:text-amber-300') ?>">
                                <?= $d['status'] ?>
                            </span>
                        </div>
                    </div>
                    <div class="price-tag">
                        <?= number_format($d['total_sum'], 0, '.', ' ') ?> ₴
                    </div>

                    <div class="actions-box">
                        <a href="print_contract.php?id=<?= $d['id_deal'] ?>"
                           target="_blank"
                           class="btn-link btn-print">Договір</a>

                        <a href="print_receipt.php?id=<?= $d['id_deal'] ?>"
                           target="_blank"
                           class="btn-link btn-print">Квитанція</a>

                        <a href="delete.php?id=<?= $d['id_deal'] ?>&table=deals&col=id_deal"
                           class="btn-link btn-del"
                           onclick="return confirm('Видалити угоду?')">Видалити</a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</main>

</body>
</html>
