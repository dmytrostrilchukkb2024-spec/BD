<?php
session_start();
require_once 'db.php';
if (!isset($_SESSION['admin_auth'])) { header("Location: login.php"); exit; }
?>
<!DOCTYPE html>
<html lang="uk" class="dark">
<head>
    <meta charset="UTF-8">
    <title>Пошук угод</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script> tailwind.config = { darkMode: 'class' } </script>
</head>
<body class="bg-gray-100 dark:bg-slate-900 text-slate-800 dark:text-slate-100 flex h-screen overflow-hidden font-sans">

<?php include 'sidebar_template.php'; ?>

<main class="flex-1 flex flex-col relative h-full">
    <header class="h-24 bg-white/80 dark:bg-slate-800/80 backdrop-blur border-b border-gray-200 dark:border-slate-700 flex flex-col justify-center px-8">
        <h2 class="text-xl font-bold mb-2">🔍 Реєстр та Пошук угод</h2>

        <div class="relative w-full max-w-xl">
            <input type="text" id="searchInput"
                   class="block w-full p-3 pl-10 text-sm text-gray-900 border border-gray-300 rounded-xl bg-gray-50 focus:ring-blue-500 focus:border-blue-500 dark:bg-slate-700 dark:border-slate-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                   placeholder="Пошук за ПІБ клієнта, послугою або ID...">
            <div class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                <svg class="w-4 h-4 text-gray-500 dark:text-gray-400" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 20 20">
                    <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m19 19-4-4m0-7A7 7 0 1 1 1 8a7 7 0 0 1 14 0Z"/>
                </svg>
            </div>
        </div>
    </header>

    <div class="p-8 flex-1 overflow-y-auto">
        <div class="bg-white dark:bg-slate-800 rounded-2xl shadow-xl border border-gray-200 dark:border-slate-700 overflow-hidden">
            <table class="w-full text-left border-collapse">
                <thead class="bg-gray-50 dark:bg-slate-700/50 text-gray-500 dark:text-gray-400 text-xs uppercase font-bold">
                    <tr>
                        <th class="px-6 py-4">ID</th>
                        <th class="px-6 py-4">Дата</th>
                        <th class="px-6 py-4">Клієнт</th>
                        <th class="px-6 py-4">Послуга</th>
                        <th class="px-6 py-4">Нотаріус</th>
                        <th class="px-6 py-4">Сума</th>
                        <th class="px-6 py-4">Статус</th>
                        <th class="px-6 py-4 text-center">Дії</th>
                    </tr>
                </thead>
                <tbody id="dealsTableBody" class="divide-y divide-gray-100 dark:divide-slate-700">
                    </tbody>
            </table>
        </div>
    </div>
</main>

<script>
    const searchInput = document.getElementById('searchInput');
    const tableBody = document.getElementById('dealsTableBody');

    function loadDeals(q = '') {
        fetch('api_search_deals.php?q=' + encodeURIComponent(q))
            .then(res => res.json())
            .then(data => {
                tableBody.innerHTML = '';
                if (data.length === 0) {
                    tableBody.innerHTML = '<tr><td colspan="8" class="px-6 py-8 text-center text-gray-500">Нічого не знайдено</td></tr>';
                    return;
                }

                data.forEach(d => {
                    const row = `
                        <tr class="hover:bg-gray-50 dark:hover:bg-slate-700/30 transition">
                            <td class="px-6 py-4 font-mono text-xs text-gray-400">#${d.id_deal}</td>
                            <td class="px-6 py-4 text-sm">${d.formatted_date}</td>
                            <td class="px-6 py-4 font-bold text-slate-700 dark:text-slate-200">${d.client_name}</td>
                            <td class="px-6 py-4 text-sm">${d.service_name}</td>
                            <td class="px-6 py-4 text-sm text-gray-500">${d.notary_name}</td>
                            <td class="px-6 py-4 font-bold text-green-600 dark:text-green-400">${d.formatted_sum} ₴</td>
                            <td class="px-6 py-4">
                                <span class="px-2 py-1 rounded-md text-xs font-bold ${d.status === 'Завершено' ? 'bg-green-100 text-green-700' : 'bg-blue-100 text-blue-700'}">
                                    ${d.status}
                                </span>
                            </td>
                            <td class="px-6 py-4 flex justify-center gap-2">
                                <button onclick="deleteDeal(${d.id_deal})" class="text-red-500 hover:text-red-700 transition">🗑️</button>
                            </td>
                        </tr>
                    `;
                    tableBody.innerHTML += row;
                });
            })
            .catch(error => {
                console.error("Помилка:", error);
                tableBody.innerHTML = '<tr><td colspan="8" class="px-6 py-8 text-center text-red-500">Помилка завантаження даних</td></tr>';
            });
    }

    function deleteDeal(id) {
        if (confirm('Ви впевнені, що хочете видалити угоду #' + id + '?')) {
            const formData = new FormData();
            formData.append('id', id);

            fetch('api_delete_deal.php', {
                method: 'POST',
                body: formData
            })
            .then(res => res.json())
            .then(result => {
                if (result.success) {
                    loadDeals(searchInput.value);
                } else {
                    alert('Помилка: ' + result.message);
                }
            })
            .catch(() => alert('Помилка при видаленні'));
        }
    }

    // Перше завантаження
    loadDeals();

    // Пошук при введенні
    searchInput.addEventListener('input', (e) => {
        loadDeals(e.target.value);
    });

    // Темна тема
    if (localStorage.getItem('theme') === 'dark' || (!('theme' in localStorage) && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
        document.documentElement.classList.add('dark');
    } else {
        document.documentElement.classList.remove('dark');
    }
</script>

</body>
</html>
