<?php
session_start();
require_once 'db.php';
header('Content-Type: application/json');

if (!isset($_SESSION['admin_auth'])) {
    echo json_encode(['success' => false, 'message' => 'Доступ заборонено']);
    exit;
}

$id = $_POST['id'] ?? 0;
$status = $_POST['status'] ?? '';

$allowed = ['Заплановано', 'В процесі', 'Завершено'];

if ($id && in_array($status, $allowed)) {
    $stmt = $pdo->prepare("UPDATE deals SET status = ? WHERE id_deal = ?");
    if ($stmt->execute([$status, $id])) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Помилка оновлення']);
    }
}
