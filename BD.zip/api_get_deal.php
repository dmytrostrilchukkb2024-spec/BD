<?php
require_once 'db.php';
$id = $_GET['id'] ?? 0;
$stmt = $pdo->prepare("SELECT id_deal, total_sum, status FROM deals WHERE id_deal = ?");
$stmt->execute([$id]);
echo json_encode($stmt->fetch(PDO::FETCH_ASSOC));
