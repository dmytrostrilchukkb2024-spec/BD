<?php
require_once 'db.php';

$q = $_GET['q'] ?? '';
header('Content-Type: application/json');

try {
    $sql = "SELECT d.id_deal, d.deal_date, d.total_sum, d.status,
                   c.full_name as client_name,
                   s.service_name,
                   n.full_name as notary_name
            FROM deals d
            LEFT JOIN clients c ON d.client_id = c.id_client
            LEFT JOIN services s ON d.service_id = s.id_service
            LEFT JOIN notaries n ON d.notary_id = n.id_notary";

    if (!empty($q)) {
        $sql .= " WHERE c.full_name LIKE :q 
                  OR s.service_name LIKE :q 
                  OR d.id_deal = :id
                  ORDER BY d.deal_date DESC";
        $stmt = $pdo->prepare($sql);
        $stmt->execute(['q' => "%$q%", 'id' => is_numeric($q) ? $q : 0]);
    } else {
        $sql .= " ORDER BY d.deal_date DESC LIMIT 20";
        $stmt = $pdo->query($sql);
    }

    $results = $stmt->fetchAll();

    foreach ($results as &$row) {
        $row['formatted_date'] = date('d.m.Y H:i', strtotime($row['deal_date']));
        $row['formatted_sum'] = number_format($row['total_sum'], 0, '.', ' ');
    }

    echo json_encode($results);
} catch (Exception $e) {
    echo json_encode(['error' => $e->getMessage()]);
}
?>