<?php
session_start();
require_once 'db.php';
if (!isset($_SESSION['admin_auth'])) { header("Location: login.php"); exit; }

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $full_name = trim($_POST['full_name']);
    $passport_s = trim($_POST['passport_series']);
    $passport_n = trim($_POST['passport_number']);
    $phone = trim($_POST['phone']);
    $address = trim($_POST['address']);

    if(!empty($full_name)) {
        // Використовуємо $pdo замість $conn
        $sql = "INSERT INTO clients (full_name, passport_series, passport_number, address, phone) VALUES (?, ?, ?, ?, ?)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$full_name, $passport_s, $passport_n, $address, $phone]);
        header("Location: clients.php");
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="uk" class="dark">
<head>
    <meta charset="UTF-8">
    <title>Новий клієнт</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script> tailwind.config = { darkMode: 'class', theme: { extend: { animation: { 'gradient': 'gradient 15s ease infinite' }, keyframes: { gradient: { '0%, 100%': { 'background-position': '0% 50%' }, '50%': { 'background-position': '100% 50%' } } } } } } </script>
    <style> .glass { background: rgba(255, 255, 255, 0.05); backdrop-filter: blur(10px); border: 1px solid rgba(255, 255, 255, 0.1); } .animate-bg { background: linear-gradient(-45deg, #1e293b, #0f172a, #334155, #1e1b4b); background-size: 400% 400%; animation: gradient 15s ease infinite; } </style>
</head>
<body class="animate-bg flex items-center justify-center min-h-screen font-sans text-gray-800 dark:text-gray-100 p-4">

<div class="glass w-full max-w-lg p-8 rounded-3xl shadow-2xl">
    <h2 class="text-3xl font-bold mb-6 text-center bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-500">👤 Новий клієнт</h2>

    <form method="POST" class="space-y-4">
        <div>
            <label class="block text-sm font-medium mb-1 opacity-80">ПІБ Клієнта</label>
            <input type="text" name="full_name" required placeholder="Іванов Іван" class="w-full p-3 rounded-xl bg-white/10 border border-white/20 focus:bg-white/20 focus:border-blue-500 outline-none transition text-white placeholder-gray-400">
        </div>

        <div class="grid grid-cols-3 gap-4">
            <div>
                <label class="block text-sm font-medium mb-1 opacity-80">Серія</label>
                <input type="text" name="passport_series" placeholder="AA" class="w-full p-3 rounded-xl bg-white/10 border border-white/20 focus:bg-white/20 outline-none transition text-white">
            </div>
            <div class="col-span-2">
                <label class="block text-sm font-medium mb-1 opacity-80">Номер паспорту</label>
                <input type="text" name="passport_number" placeholder="123456" class="w-full p-3 rounded-xl bg-white/10 border border-white/20 focus:bg-white/20 outline-none transition text-white">
            </div>
        </div>

        <div>
            <label class="block text-sm font-medium mb-1 opacity-80">Адреса</label>
            <input type="text" name="address" placeholder="м. Київ, вул..." class="w-full p-3 rounded-xl bg-white/10 border border-white/20 focus:bg-white/20 outline-none transition text-white">
        </div>

        <div>
            <label class="block text-sm font-medium mb-1 opacity-80">Телефон</label>
            <input type="tel" name="phone" placeholder="+380..." class="w-full p-3 rounded-xl bg-white/10 border border-white/20 focus:bg-white/20 outline-none transition text-white">
        </div>

        <div class="flex gap-4 pt-4">
            <a href="clients.php" class="flex-1 py-3 text-center rounded-xl bg-gray-600/50 hover:bg-gray-600/80 transition text-white font-semibold">Скасувати</a>
            <button type="submit" class="flex-1 py-3 rounded-xl bg-blue-600 hover:bg-blue-500 shadow-lg shadow-blue-500/30 transition text-white font-bold">Зберегти</button>
        </div>
    </form>
</div>

</body>
</html>
