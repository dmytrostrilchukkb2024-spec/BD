<?php
session_start();
require_once 'db.php';

// Перевірка авторизації
if (!isset($_SESSION['admin_auth'])) { header("Location: login.php"); exit; }

$type = $_GET['type'] ?? '';
$id = $_GET['id'] ?? 0;
$data = null;
$title = "Редагування";

// 1. Отримання даних
if ($type === 'client') {
    $stmt = $pdo->prepare("SELECT * FROM clients WHERE id_client = ?");
    $stmt->execute([$id]);
    $data = $stmt->fetch();
    $title = "Редагування клієнта";
} elseif ($type === 'notary') {
    $stmt = $pdo->prepare("SELECT * FROM notaries WHERE id_notary = ?");
    $stmt->execute([$id]);
    $data = $stmt->fetch();
    $title = "Редагування нотаріуса";
} elseif ($type === 'service') {
    $stmt = $pdo->prepare("SELECT * FROM services WHERE id_service = ?");
    $stmt->execute([$id]);
    $data = $stmt->fetch();
    $title = "Редагування послуги";
}

if (!$data) { die("Запис не знайдено!"); }

// 2. Збереження змін
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($type === 'client') {
        $sql = "UPDATE clients SET full_name=?, passport_series=?, passport_number=?, address=?, phone=? WHERE id_client=?";
        $pdo->prepare($sql)->execute([$_POST['full_name'], $_POST['passport_series'], $_POST['passport_number'], $_POST['address'], $_POST['phone'], $id]);
        header("Location: clients.php"); exit;
    } elseif ($type === 'notary') {
        $sql = "UPDATE notaries SET full_name=?, license_number=?, work_phone=?, cabinet_number=? WHERE id_notary=?";
        $pdo->prepare($sql)->execute([$_POST['full_name'], $_POST['license_number'], $_POST['work_phone'], $_POST['cabinet_number'], $id]);
        header("Location: notaries.php"); exit;
    } elseif ($type === 'service') {
        $sql = "UPDATE services SET service_name=?, price=?, duration_minutes=?, description=? WHERE id_service=?";
        $pdo->prepare($sql)->execute([$_POST['service_name'], $_POST['price'], $_POST['duration_minutes'], $_POST['description'], $id]);
        header("Location: services.php"); exit;
    }
}
?>

<!DOCTYPE html>
<html lang="uk" class="dark">
<head>
    <meta charset="UTF-8">
    <title><?= $title ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script> tailwind.config = { darkMode: 'class' } </script>
</head>
<body class="bg-gray-100 dark:bg-slate-900 text-slate-800 dark:text-slate-100 flex items-center justify-center min-h-screen p-6 font-sans">

<div class="w-full max-w-xl bg-white dark:bg-slate-800 p-10 rounded-3xl shadow-2xl border border-gray-200 dark:border-slate-700 relative">
    <div class="absolute top-6 right-6">
        <button id="theme-toggle" class="p-2 rounded-lg bg-gray-100 dark:bg-slate-700 hover:bg-gray-200 dark:hover:bg-slate-600 transition">
            <span id="sun-icon">☀️</span>
            <span id="moon-icon" class="hidden">🌙</span>
        </button>
    </div>

    <h2 class="text-2xl font-bold mb-8 text-center text-blue-600 dark:text-blue-400"><?= $title ?></h2>

    <form method="POST" class="space-y-5">
        <?php if($type === 'client'): ?>
            <div>
                <label class="block text-xs font-bold text-gray-400 uppercase mb-1">ПІБ Клієнта</label>
                <input type="text" name="full_name" value="<?= htmlspecialchars($data['full_name']) ?>" required
                       class="w-full p-3 rounded-xl bg-gray-50 dark:bg-slate-700 border border-gray-200 dark:border-slate-600 outline-none focus:ring-2 focus:ring-blue-500 transition">
            </div>
            <div class="grid grid-cols-2 gap-4">
                <input type="text" name="passport_series" placeholder="Серія" value="<?= htmlspecialchars($data['passport_series']) ?>" class="p-3 rounded-xl bg-gray-50 dark:bg-slate-700 border border-gray-200 dark:border-slate-600 outline-none">
                <input type="text" name="passport_number" placeholder="Номер" value="<?= htmlspecialchars($data['passport_number']) ?>" class="p-3 rounded-xl bg-gray-50 dark:bg-slate-700 border border-gray-200 dark:border-slate-600 outline-none">
            </div>
            <input type="text" name="phone" placeholder="Телефон" value="<?= htmlspecialchars($data['phone']) ?>" class="w-full p-3 rounded-xl bg-gray-50 dark:bg-slate-700 border border-gray-200 dark:border-slate-600 outline-none">
            <input type="text" name="address" placeholder="Адреса" value="<?= htmlspecialchars($data['address']) ?>" class="w-full p-3 rounded-xl bg-gray-50 dark:bg-slate-700 border border-gray-200 dark:border-slate-600 outline-none">

        <?php elseif($type === 'notary'): ?>
            <input type="text" name="full_name" value="<?= htmlspecialchars($data['full_name']) ?>" required class="w-full p-3 rounded-xl bg-gray-50 dark:bg-slate-700 border border-gray-200 dark:border-slate-600 outline-none">
            <input type="text" name="license_number" value="<?= htmlspecialchars($data['license_number']) ?>" placeholder="Ліцензія" class="w-full p-3 rounded-xl bg-gray-50 dark:bg-slate-700 border border-gray-200 dark:border-slate-600 outline-none">
            <div class="grid grid-cols-2 gap-4">
                <input type="text" name="work_phone" value="<?= htmlspecialchars($data['work_phone']) ?>" placeholder="Телефон" class="p-3 rounded-xl bg-gray-50 dark:bg-slate-700 border border-gray-200 dark:border-slate-600 outline-none">
                <input type="text" name="cabinet_number" value="<?= htmlspecialchars($data['cabinet_number']) ?>" placeholder="Кабінет" class="p-3 rounded-xl bg-gray-50 dark:bg-slate-700 border border-gray-200 dark:border-slate-600 outline-none">
            </div>

        <?php elseif($type === 'service'): ?>
            <input type="text" name="service_name" value="<?= htmlspecialchars($data['service_name']) ?>" required class="w-full p-3 rounded-xl bg-gray-50 dark:bg-slate-700 border border-gray-200 dark:border-slate-600 outline-none">
            <div class="grid grid-cols-2 gap-4">
                <input type="number" step="0.01" name="price" value="<?= $data['price'] ?>" placeholder="Ціна" class="p-3 rounded-xl bg-gray-50 dark:bg-slate-700 border border-gray-200 dark:border-slate-600 outline-none">
                <input type="number" name="duration_minutes" value="<?= $data['duration_minutes'] ?>" placeholder="Хвилини" class="p-3 rounded-xl bg-gray-50 dark:bg-slate-700 border border-gray-200 dark:border-slate-600 outline-none">
            </div>
            <div>
                <label class="block text-xs font-bold text-gray-400 uppercase mb-1">Опис</label>
                <textarea name="description" rows="3" class="w-full p-3 rounded-xl bg-gray-50 dark:bg-slate-700 border border-gray-200 dark:border-slate-600 outline-none"><?= htmlspecialchars($data['description']) ?></textarea>
            </div>
        <?php endif; ?>

        <div class="flex gap-4 pt-4">
            <a href="javascript:history.back()"
               class="flex-1 py-3 text-center rounded-xl bg-gray-200 dark:bg-slate-700 hover:bg-gray-300 dark:hover:bg-slate-600 transition font-bold text-gray-700 dark:text-gray-300">
                Скасувати
            </a>
            <button type="submit"
                    class="flex-1 py-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold shadow-lg transition transform hover:-translate-y-1">
                Зберегти зміни
            </button>
        </div>
    </form>
</div>

<script>
    const themeBtn = document.getElementById('theme-toggle');
    const sunIcon = document.getElementById('sun-icon');
    const moonIcon = document.getElementById('moon-icon');
    const htmlEl = document.documentElement;

    function updateIcons() {
        if (htmlEl.classList.contains('dark')) {
            sunIcon.classList.remove('hidden');
            moonIcon.classList.add('hidden');
        } else {
            sunIcon.classList.add('hidden');
            moonIcon.classList.remove('hidden');
        }
    }
    updateIcons();

    themeBtn.addEventListener('click', () => {
        htmlEl.classList.toggle('dark');
        localStorage.setItem('theme', htmlEl.classList.contains('dark') ? 'dark' : 'light');
        updateIcons();
    });

    if (localStorage.getItem('theme') === 'dark') {
        htmlEl.classList.add('dark');
        updateIcons();
    }
</script>

</body>
</html>
