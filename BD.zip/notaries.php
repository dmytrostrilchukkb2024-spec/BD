<?php
session_start();
require_once 'db.php';

// Перевірка входу
if (!isset($_SESSION['admin_auth'])) { header("Location: login.php"); exit; }

// --- ЛОГІКА СОРТУВАННЯ ---

// 1. Отримуємо параметри сортування
$sort = $_GET['sort'] ?? 'id_notary'; // За ID за замовчуванням
$order = $_GET['order'] ?? 'ASC';

// 2. Перевірка дозволених колонок та напрямку (для безпеки)
$allowed_cols = ['id_notary', 'full_name', 'license_number', 'cabinet_number'];
$allowed_order = ['ASC', 'DESC'];

if (!in_array($sort, $allowed_cols)) {
    $sort = 'id_notary';
}
if (!in_array($order, $allowed_order)) {
    $order = 'ASC';
}

// 3. Формуємо SQL запит
$sql = "SELECT * FROM notaries ORDER BY {$sort} {$order}";
$rows = $pdo->query($sql)->fetchAll();


// --- ЛОГІКА ДОДАВАННЯ ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_notary'])) {
    $name = trim($_POST['full_name']);
    $phone = trim($_POST['work_phone']);
    $lic = trim($_POST['license_number']);
    $cab = trim($_POST['cabinet_number']);

    if(!empty($name)) {
        $stmt = $pdo->prepare("INSERT INTO notaries (full_name, work_phone, license_number, cabinet_number) VALUES (?, ?, ?, ?)");
        $stmt->execute([$name, $phone, $lic, $cab]);
        header("Location: notaries.php");
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="uk" class="dark">
<head>
    <meta charset="UTF-8">
    <title>Нотаріуси | Admin Panel</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script> tailwind.config = { darkMode: 'class' } </script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <script>
        if (localStorage.getItem('theme') === 'dark' || (!('theme' in localStorage) && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
            document.documentElement.classList.add('dark');
        } else {
            document.documentElement.classList.remove('dark');
        }
    </script>

    <style>
        /* Стилі для карток нотаріусів */
        .person-card {
            background-color: #fff;
            border-radius: 1rem;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -2px rgba(0, 0, 0, 0.1);
            padding: 1.5rem;
            transition: all 0.2s;
            border: 1px solid #e5e7eb;
        }
        .dark .person-card {
            background-color: #334155;
            border-color: #475569;
        }
        .person-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -4px rgba(0, 0, 0, 0.1);
        }
        .person-header {
            display: flex;
            align-items: center;
            margin-bottom: 1rem;
            border-bottom: 1px dashed #e5e7eb;
            padding-bottom: 1rem;
        }
        .dark .person-header {
            border-bottom: 1px dashed #475569;
        }
        .avatar {
            width: 3rem;
            height: 3rem;
            border-radius: 50%;
            background-color: #3b82f6;
            color: white;
            display: flex;
            justify-content: center;
            align-items: center;
            font-size: 1.5rem;
            font-weight: bold;
            margin-right: 1rem;
        }
        .name {
            font-size: 1.25rem;
            font-weight: 600;
        }
        .info-row {
            display: flex;
            justify-content: space-between;
            font-size: 0.875rem;
            padding: 0.5rem 0;
            border-bottom: 1px dotted #f3f4f6;
        }
        .dark .info-row {
            border-bottom: 1px dotted #475569;
        }
        .actions {
            display: flex;
            justify-content: flex-end;
            gap: 0.5rem;
            margin-top: 1rem;
        }
        .btn {
            padding: 0.5rem 0.75rem;
            border-radius: 0.5rem;
            font-size: 0.75rem;
            font-weight: 600;
            transition: background-color 0.15s;
        }
        .btn-edit {
            background-color: #dbeafe;
            color: #2563eb;
        }
        .dark .btn-edit {
            background-color: #1e3a8a;
            color: #93c5fd;
        }
        .btn-del {
            background-color: #fee2e2;
            color: #dc2626;
        }
        .dark .btn-del {
            background-color: #7f1d1d;
            color: #fca5a5;
        }
        .btn:hover {
            opacity: 0.8;
        }
    </style>
</head>
<body class="bg-gray-100 dark:bg-slate-900 text-slate-800 dark:text-slate-100 flex h-screen overflow-hidden font-sans">

<?php include 'sidebar_template.php'; ?>

<main class="flex-1 flex flex-col relative h-full">
    <header class="h-24 bg-white/80 dark:bg-slate-800/80 backdrop-blur border-b border-gray-200 dark:border-slate-700 flex items-center px-8 sticky top-0 z-10">
        <h2 class="text-2xl font-bold flex items-center gap-2">⚖️ Управління нотаріусами</h2>
    </header>

    <div class="p-8 flex-1 overflow-y-auto">
        <div class="bg-white dark:bg-slate-800 p-6 rounded-2xl shadow-xl mb-8 border border-gray-100 dark:border-slate-700">
            <h3 class="text-xl font-semibold mb-4 text-blue-600 dark:text-blue-400">Додати нового співробітника</h3>
            <form method="POST" class="grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
                <div class="md:col-span-1">
                    <label class="block text-xs uppercase font-bold text-gray-500 dark:text-gray-400 mb-1">ПІБ</label>
                    <input type="text" name="full_name" required placeholder="Іванов Іван Іванович"
                           class="w-full p-3 rounded-xl bg-gray-50 dark:bg-slate-700 border border-gray-300 dark:border-slate-600 focus:ring-2 focus:ring-blue-500 outline-none transition">
                </div>
                <div>
                    <label class="block text-xs uppercase font-bold text-gray-500 dark:text-gray-400 mb-1">Телефон</label>
                    <input type="text" name="work_phone" placeholder="+380..."
                           class="w-full p-3 rounded-xl bg-gray-50 dark:bg-slate-700 border border-gray-300 dark:border-slate-600 focus:ring-2 focus:ring-blue-500 outline-none transition">
                </div>
                <div>
                    <label class="block text-xs uppercase font-bold text-gray-500 dark:text-gray-400 mb-1">№ Ліцензії</label>
                    <input type="text" name="license_number" placeholder="123456"
                           class="w-full p-3 rounded-xl bg-gray-50 dark:bg-slate-700 border border-gray-300 dark:border-slate-600 focus:ring-2 focus:ring-blue-500 outline-none transition">
                </div>
                <div>
                    <label class="block text-xs uppercase font-bold text-gray-500 dark:text-gray-400 mb-1">Кабінет</label>
                    <input type="text" name="cabinet_number" placeholder="№10"
                           class="w-full p-3 rounded-xl bg-gray-50 dark:bg-slate-700 border border-gray-300 dark:border-slate-600 focus:ring-2 focus:ring-blue-500 outline-none transition">
                </div>
                <div class="md:col-span-4 flex justify-end mt-2">
                    <button type="submit" name="add_notary"
                            class="bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-8 rounded-xl shadow-lg shadow-blue-500/30 transition transform hover:scale-105">
                        ➕ Додати нотаріуса
                    </button>
                </div>
            </form>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <?php foreach ($rows as $p): ?>
                <div class="person-card">
                    <div class="person-header">
                        <div class="avatar">
                            <?= mb_substr($p['full_name'], 0, 1) ?>
                        </div>
                        <div class="name">
                            <?= htmlspecialchars($p['full_name']) ?>
                        </div>
                    </div>

                    <div class="info-row">
                        <span>📞 Телефон:</span>
                        <span class="font-medium text-gray-700 dark:text-gray-200"><?= htmlspecialchars($p['work_phone']) ?></span>
                    </div>
                    <div class="info-row">
                        <span>📜 Ліцензія:</span>
                        <span class="font-medium text-gray-700 dark:text-gray-200"><?= htmlspecialchars($p['license_number']) ?></span>
                    </div>
                    <div class="info-row">
                        <span>🚪 Кабінет:</span>
                        <span class="font-bold text-lg text-purple-600 dark:text-purple-300"><?= htmlspecialchars($p['cabinet_number']) ?></span>
                    </div>

                    <div class="actions">
                        <a href="edit.php?type=notary&id=<?= $p['id_notary'] ?>" class="btn btn-edit">Редагувати</a>

                        <a href="delete.php?id=<?= $p['id_notary'] ?>&table=notaries&col=id_notary"
                           class="btn btn-del"
                           onclick="return confirm('Ви впевнені, що хочете видалити співробітника?')">Видалити</a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</main>
</body>
</html>
