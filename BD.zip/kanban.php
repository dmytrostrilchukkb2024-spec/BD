<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['admin_auth'])) { header("Location: login.php"); exit; }

// --- ЛОГІКА СОРТУВАННЯ ---
$sort = $_GET['sort'] ?? 'd.deal_date';
$order = $_GET['order'] ?? 'DESC';
$allowed_cols = ['d.deal_date', 'd.total_sum', 'c.full_name', 's.service_name'];
if (!in_array($sort, $allowed_cols)) $sort = 'd.deal_date';
if (!in_array($order, ['ASC', 'DESC'])) $order = 'DESC';

$sql = "SELECT d.*, c.full_name, s.service_name 
        FROM deals d
        LEFT JOIN clients c ON d.client_id = c.id_client
        LEFT JOIN services s ON d.service_id = s.id_service
        ORDER BY {$sort} {$order}";

try {
    $deals = $pdo->query($sql)->fetchAll();
} catch (PDOException $e) { die("Помилка БД: " . $e->getMessage()); }

$columns = ['Заплановано' => [], 'В процесі' => [], 'Завершено' => []];
foreach ($deals as $deal) {
    $columns[$deal['status'] ?? 'Заплановано'][] = $deal;
}

function renderCard($d, $color) {
    $date = date('d.m H:i', strtotime($d['deal_date']));
    echo "
    <div class='bg-white dark:bg-slate-700 p-4 rounded-xl shadow-sm border-l-4 $color mb-4 group hover:shadow-md transition cursor-pointer relative'
         onclick='openEditModal({$d['id_deal']})'>
        <div class='text-[10px] font-bold text-gray-400 mb-1 flex justify-between'>
            <span>#{$d['id_deal']} • $date</span>
            <button onclick='event.stopPropagation(); deleteDeal({$d['id_deal']})' class='opacity-0 group-hover:opacity-100 text-red-400 hover:text-red-600 transition'>🗑️</button>
        </div>
        <div class='font-bold text-slate-800 dark:text-slate-100 text-sm mb-1 line-clamp-2'>{$d['service_name']}</div>
        <div class='text-xs text-gray-500 dark:text-gray-400'>👤 {$d['full_name']}</div>
        <div class='mt-3 flex items-center justify-between'>
            <span class='text-xs font-black text-blue-600 dark:text-blue-400'>".number_format($d['total_sum'],0,'.',' ')." ₴</span>
            <select onchange='event.stopPropagation(); changeStatus({$d['id_deal']}, this.value)' 
                    class='text-[10px] bg-gray-100 dark:bg-slate-600 border-none rounded px-1 py-0.5 outline-none focus:ring-1 ring-blue-500'>
                <option value='Заплановано' ".($d['status']=='Заплановано'?'selected':'').">План</option>
                <option value='В процесі' ".($d['status']=='В процесі'?'selected':'').">Процес</option>
                <option value='Завершено' ".($d['status']=='Завершено'?'selected':'').">Готово</option>
            </select>
        </div>
    </div>";
}
?>

<!DOCTYPE html>
<html lang="uk" class="dark">
<head>
    <meta charset="UTF-8">
    <title>Угоди | Kanban</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script> tailwind.config = { darkMode: 'class' } </script>
</head>
<body class="bg-gray-100 dark:bg-slate-900 text-slate-800 dark:text-slate-100 flex h-screen overflow-hidden font-sans">

<?php include 'sidebar_template.php'; ?>

<main class="flex-1 flex flex-col relative h-full">
    <header class="h-20 bg-white/80 dark:bg-slate-800/80 backdrop-blur border-b border-gray-200 dark:border-slate-700 flex items-center justify-between px-8 sticky top-0 z-10">
        <h2 class="text-xl font-bold">📋 Дошка угод</h2>
        <div class="flex gap-4">
            <a href="deals_search.php" class="px-4 py-2 bg-gray-200 dark:bg-slate-700 rounded-xl hover:bg-gray-300 dark:hover:bg-slate-600 transition font-bold text-sm">🔍 Пошук</a>
            <a href="create.php" class="px-4 py-2 bg-blue-600 text-white rounded-xl hover:bg-blue-700 transition font-bold text-sm shadow-lg shadow-blue-500/20">+ Нова угода</a>
        </div>
    </header>

    <div class="p-6 grid grid-cols-1 md:grid-cols-3 gap-6 flex-1 overflow-hidden">
        
        <div class="flex flex-col bg-gray-200/50 dark:bg-slate-800/50 rounded-2xl p-4 border border-gray-200 dark:border-slate-700 h-full">
            <h3 class="font-black uppercase text-xs text-gray-500 mb-4 px-2 flex justify-between">
                📌 Заплановано <span><?= count($columns['Заплановано']) ?></span>
            </h3>
            <div class="flex-1 overflow-y-auto pr-1">
                <?php foreach($columns['Заплановано'] as $d) renderCard($d, 'border-amber-400'); ?>
            </div>
        </div>

        <div class="flex flex-col bg-gray-200/50 dark:bg-slate-800/50 rounded-2xl p-4 border border-gray-200 dark:border-slate-700 h-full">
            <h3 class="font-black uppercase text-xs text-blue-500 mb-4 px-2 flex justify-between">
                ⚡ В процесі <span><?= count($columns['В процесі']) ?></span>
            </h3>
            <div class="flex-1 overflow-y-auto pr-1">
                <?php foreach($columns['В процесі'] as $d) renderCard($d, 'border-blue-500'); ?>
            </div>
        </div>

        <div class="flex flex-col bg-gray-200/50 dark:bg-slate-800/50 rounded-2xl p-4 border border-gray-200 dark:border-slate-700 h-full">
            <h3 class="font-black uppercase text-xs text-green-500 mb-4 px-2 flex justify-between">
                ✅ Завершено <span><?= count($columns['Завершено']) ?></span>
            </h3>
            <div class="flex-1 overflow-y-auto pr-1">
                <?php foreach($columns['Завершено'] as $d) renderCard($d, 'border-green-500'); ?>
            </div>
        </div>

    </div>
</main>

<div id="editModal" class="fixed inset-0 bg-black/60 backdrop-blur-sm hidden z-50 flex items-center justify-center p-4">
    <div class="bg-white dark:bg-slate-800 w-full max-w-md p-8 rounded-3xl shadow-2xl relative">
        <button onclick="closeModal()" class="absolute top-4 right-4 text-gray-400 hover:text-white text-2xl">&times;</button>
        <h3 class="text-xl font-bold mb-6">Редагувати угоду</h3>
        <form id="editForm" action="api_edit_deal.php" method="POST" class="space-y-4">
            <input type="hidden" name="id_deal" id="edit_id">
            <div>
                <label class="block text-xs font-bold text-gray-400 uppercase mb-1">Загальна Сума (грн)</label>
                <input type="number" name="total_sum" id="edit_sum" step="0.01" class="w-full p-3 rounded-xl bg-gray-50 dark:bg-slate-700 border border-gray-200 dark:border-slate-600 outline-none">
            </div>
            <div>
                <label class="block text-xs font-bold text-gray-400 uppercase mb-1">Статус</label>
                <select name="status" id="edit_status" class="w-full p-3 rounded-xl bg-gray-50 dark:bg-slate-700 border border-gray-200 dark:border-slate-600 outline-none">
                    <option value="Заплановано">Заплановано</option>
                    <option value="В процесі">В процесі</option>
                    <option value="Завершено">Завершено</option>
                </select>
            </div>
            <div class="flex gap-3 pt-4">
                <button type="button" onclick="closeModal()" class="flex-1 py-3 rounded-xl bg-gray-100 dark:bg-slate-700 font-bold">Скасувати</button>
                <button type="submit" class="flex-1 py-3 rounded-xl bg-blue-600 text-white hover:bg-blue-700 transition shadow-lg shadow-blue-500/30">Зберегти</button>
            </div>
        </form>
    </div>
</div>

<script>
function changeStatus(id, newStatus) {
    const fd = new FormData(); fd.append('id', id); fd.append('status', newStatus);
    fetch('api_update_status.php', { method: 'POST', body: fd }).then(() => location.reload());
}

function deleteDeal(id) {
    if (confirm('Видалити угоду?')) {
        const fd = new FormData(); fd.append('id', id);
        fetch('api_delete_deal.php', { method: 'POST', body: fd }).then(() => location.reload());
    }
}

// РЕДАГУВАННЯ
function openEditModal(id) {
    fetch('api_get_deal.php?id=' + id)
        .then(res => res.json())
        .then(data => {
            document.getElementById('edit_id').value = data.id_deal;
            document.getElementById('edit_sum').value = data.total_sum;
            document.getElementById('edit_status').value = data.status;
            document.getElementById('editModal').classList.remove('hidden');
        });
}

function closeModal() { document.getElementById('editModal').classList.add('hidden'); }

document.getElementById('editForm').onsubmit = function(e) {
    e.preventDefault();
    fetch('api_edit_deal.php', { method: 'POST', body: new FormData(this) })
        .then(res => res.json())
        .then(res => { if(res.success) location.reload(); else alert('Помилка'); });
};

// Темна тема
if (localStorage.theme === 'dark' || (!('theme' in localStorage) && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
    document.documentElement.classList.add('dark');
}
</script>

</body>
</html>
