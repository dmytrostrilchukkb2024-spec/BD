<?php
session_start();
require_once 'db.php';
if (!isset($_SESSION['admin_auth'])) { header("Location: login.php"); exit; }

// Отримуємо списки для вибору (PDO)
$clients = $pdo->query("SELECT * FROM clients ORDER BY full_name")->fetchAll();
$notaries = $pdo->query("SELECT * FROM notaries ORDER BY full_name")->fetchAll();
$services = $pdo->query("SELECT * FROM services ORDER BY service_name")->fetchAll();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $client_id = $_POST['client_id'];
    $notary_id = $_POST['notary_id'];
    $service_id = $_POST['service_id'];
    $total_sum = $_POST['total_sum'];
    $status = $_POST['status'];

    $sql = "INSERT INTO deals (client_id, notary_id, service_id, total_sum, status) VALUES (?, ?, ?, ?, ?)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$client_id, $notary_id, $service_id, $total_sum, $status]);
    header("Location: kanban.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="uk" class="dark">
<head>
    <meta charset="UTF-8">
    <title>Нова угода</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script> tailwind.config = { darkMode: 'class' } </script>
</head>
<body class="bg-slate-900 text-gray-100 flex items-center justify-center min-h-screen p-6">

<div class="w-full max-w-2xl bg-slate-800 p-10 rounded-3xl shadow-2xl border border-slate-700">
    <h2 class="text-3xl font-extrabold mb-8 text-center bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-500">
        🆕 Створення нової угоди
    </h2>

    <form method="POST" class="space-y-6">
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
                <label class="block text-sm font-bold text-gray-400 mb-2">Клієнт</label>
                <select name="client_id" required class="w-full p-4 rounded-xl bg-gray-900 border border-gray-700 focus:border-blue-500 outline-none cursor-pointer">
                    <?php foreach($clients as $c): ?>
                        <option value="<?= $c['id_client'] ?>"><?= htmlspecialchars($c['full_name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div>
                <label class="block text-sm font-bold text-gray-400 mb-2">Послуга</label>
                <select name="service_id" required class="w-full p-4 rounded-xl bg-gray-900 border border-gray-700 focus:border-blue-500 outline-none cursor-pointer">
                    <?php foreach($services as $s): ?>
                        <option value="<?= $s['id_service'] ?>"><?= htmlspecialchars($s['service_name']) ?> (<?= $s['price'] ?> ₴)</option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
                <label class="block text-sm font-bold text-gray-400 mb-2">Сума (грн)</label>
                <input type="number" name="total_sum" step="0.01" required class="w-full p-4 rounded-xl bg-gray-900 border border-gray-700 focus:border-blue-500 outline-none">
            </div>

            <div>
                <label class="block text-sm font-bold text-gray-400 mb-2">Нотаріус</label>
                <select name="notary_id" required class="w-full p-4 rounded-xl bg-gray-900 border border-gray-700 focus:border-blue-500 outline-none cursor-pointer">
                    <?php foreach($notaries as $n): ?>
                        <option value="<?= $n['id_notary'] ?>"><?= htmlspecialchars($n['full_name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div>
                <label class="block text-sm font-bold text-gray-400 mb-2">Статус</label>
                <select name="status" class="w-full p-4 rounded-xl bg-gray-800 border border-gray-700 focus:border-blue-500 outline-none cursor-pointer">
                    <option value="Заплановано">📌 Заплановано</option>
                    <option value="В процесі">⚡ В процесі</option>
                    <option value="Завершено">✅ Завершено</option>
                </select>
            </div>
        </div>

        <div class="flex gap-4 pt-6">
            <a href="kanban.php" class="flex-1 py-4 text-center rounded-xl bg-gray-700 hover:bg-gray-600 transition font-bold text-gray-300">Скасувати</a>
            <button type="submit" class="flex-1 py-4 rounded-xl bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 font-bold text-white shadow-lg transform hover:-translate-y-1 transition">Створити угоду</button>
        </div>
    </form>
</div>

</body>
</html>
