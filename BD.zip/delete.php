<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['admin_auth'])) { die("Доступ заборонено"); }

if (isset($_GET['id'], $_GET['table'], $_GET['col'])) {
    $id = (int)$_GET['id'];
    $table = $_GET['table'];
    $col = $_GET['col']; // Назва колонки ID (наприклад id_notary)

    // Список дозволених таблиць (White list)
    $allowed = ['clients', 'services', 'notaries', 'deals'];

    if (in_array($table, $allowed)) {
        // Захист від SQL ін'єкцій: вставляємо ім'я таблиці та колонки тільки якщо вони в білому списку
        // Але значення ID передаємо через параметр
        $sql = "DELETE FROM $table WHERE $col = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$id]);
    }
}
// Повернення на попередню сторінку
header("Location: " . $_SERVER['HTTP_REFERER']);
exit;
?>
