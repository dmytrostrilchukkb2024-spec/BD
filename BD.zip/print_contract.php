PHP
<?php
session_start(); require_once 'db.php';
if (!isset($_SESSION['admin_auth'])) { header("Location: login.php"); exit; }
$id = $_GET['id'] ?? 0;

$sql = "SELECT d.*, c.full_name as c_name, c.passport_series, c.passport_number, c.address, 
        s.service_name, s.price, s.description,
        n.full_name as n_name, n.license_number
        FROM deals d
        LEFT JOIN clients c ON d.client_id = c.id_client
        LEFT JOIN services s ON d.service_id = s.id_service
        LEFT JOIN notaries n ON d.notary_id = n.id_notary
        WHERE d.id_deal = ?";
$stmt = $pdo->prepare($sql);
$stmt->execute([$id]);
$deal = $stmt->fetch();
if (!$deal) die("Угоду не знайдено!");

// Дата
$day = date('d');
$month = date('m');
$year = date('Y');
?>
<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="UTF-8">
    <title>Договір №<?= $deal['id_deal'] ?></title>
    <style>
        body { background: #555; padding: 20px; font-family: 'Times New Roman', serif; }
        .page { background: white; width: 21cm; min-height: 29.7cm; margin: 0 auto; padding: 2.5cm 2cm; box-shadow: 0 0 10px rgba(0,0,0,0.5); position: relative; }
        .btn-print { position: fixed; top: 20px; right: 20px; background: #2ecc71; color: white; padding: 15px 30px; border: none; font-size: 1.2rem; cursor: pointer; border-radius: 8px; box-shadow: 0 5px 15px rgba(0,0,0,0.3); }
        .btn-print:hover { background: #27ae60; transform: translateY(-2px); }

        h1 { text-align: center; font-size: 16pt; margin-bottom: 5px; text-transform: uppercase; }
        h2 { text-align: center; font-size: 14pt; margin-bottom: 30px; font-weight: normal; }
        p { text-align: justify; text-indent: 1cm; margin-bottom: 12px; line-height: 1.5; font-size: 12pt; }
        .bold { font-weight: bold; }
        .header-row { display: flex; justify-content: space-between; margin-bottom: 20px; font-weight: bold; }

        .signatures { display: flex; justify-content: space-between; margin-top: 60px; }
        .sign-box { width: 45%; }
        .line { border-bottom: 1px solid black; margin-top: 40px; margin-bottom: 5px; }
        .center { text-align: center; font-size: 10pt; }

        @media print {
            body { background: white; padding: 0; }
            .btn-print { display: none; }
            .page { box-shadow: none; margin: 0; padding: 1.5cm; width: 100%; }
        }
    </style>
</head>
<body>

<button class="btn-print" onclick="window.print()">🖨 ДРУКУВАТИ ДОГОВІР</button>

<div class="page">
    <h1>ДОГОВІР №<?= $deal['id_deal'] ?></h1>
    <h2>про надання нотаріальних послуг</h2>

    <div class="header-row">
        <span>Київ, Україна</span>
        <span>«<?= $day ?>» <?= $month ?> <?= $year ?> року</span>
    </div>

    <p>
        Ми, що нижче підписалися: <span class="bold">Приватний нотаріус <?= htmlspecialchars($deal['n_name']) ?></span>, 
        що діє на підставі Свідоцтва про право на зайняття нотаріальною діяльністю №<?= htmlspecialchars($deal['license_number']) ?> (надалі — «Виконавець»), з однієї сторони, 
        та <span class="bold"><?= htmlspecialchars($deal['c_name']) ?></span>, паспорт серія <?= htmlspecialchars($deal['passport_series']) ?> №<?= htmlspecialchars($deal['passport_number']) ?>, 
        що проживає за адресою: <?= htmlspecialchars($deal['address']) ?> (надалі — «Замовник»), з іншої сторони, 
        уклали цей Договір про наступне:
    </p>

    <h3 style="text-align:center; margin-top:20px;">1. ПРЕДМЕТ ДОГОВОРУ</h3>
    <p>1.1. Замовник доручає, а Виконавець бере на себе зобов'язання надати наступні нотаріальні послуги:</p>
    <p style="padding-left: 1cm; font-style: italic;">— <?= htmlspecialchars($deal['service_name']) ?></p>
    <p>1.2. Детальний опис: <?= htmlspecialchars($deal['description']) ?>.</p>

    <h3 style="text-align:center; margin-top:20px;">2. ВАРТІСТЬ ПОСЛУГ</h3>
    <p>2.1. Загальна вартість послуг за цим Договором складає:</p>
    <p style="text-align: center; font-weight: bold; font-size: 14pt; margin: 20px 0;">
        <?= number_format($deal['total_sum'], 2) ?> ГРН
    </p>
    <p>2.2. Оплата здійснюється Замовником у повному обсязі в день підписання цього Договору.</p>

    <h3 style="text-align:center; margin-top:20px;">3. АДРЕСИ ТА ПІДПИСИ СТОРІН</h3>
    
    <div class="signatures">
        <div class="sign-box">
            <span class="bold">ВИКОНАВЕЦЬ:</span><br>
            Приватний нотаріус<br>
            <?= htmlspecialchars($deal['n_name']) ?><br>
            Ліцензія №<?= htmlspecialchars($deal['license_number']) ?>
            <div class="line"></div>
            <div class="center">(підпис)</div>
        </div>
        <div class="sign-box">
            <span class="bold">ЗАМОВНИК:</span><br>
            <?= htmlspecialchars($deal['c_name']) ?><br>
            Адреса: <?= htmlspecialchars($deal['address']) ?>
            <div class="line"></div>
            <div class="center">(підпис)</div>
        </div>
    </div>

    <div style="margin-top: 100px; text-align: center;">
        <p style="text-align: center; font-size: 10pt; color: #777;">М.П.</p>
    </div>
</div>

</body>
</html>
