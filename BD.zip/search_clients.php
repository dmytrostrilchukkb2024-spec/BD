<?php
require_once 'db.php';

$q = $_GET['q'] ?? '';

if ($q) {
    $stmt = $pdo->prepare("SELECT * FROM clients WHERE full_name LIKE ? OR phone LIKE ? ORDER BY id_client DESC");
    $stmt->execute(["%$q%", "%$q%"]);
    $clients = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Віддаємо результат у форматі JSON
    header('Content-Type: application/json');
    echo json_encode($clients);
} else {
    // Якщо запит пустий, повертаємо всіх (ліміт 50)
    $stmt = $pdo->query("SELECT * FROM clients ORDER BY id_client DESC LIMIT 50");
    header('Content-Type: application/json');
    echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
}
?>
