<?php
session_start();
require_once 'db.php';
if (!isset($_SESSION['admin_auth'])) { header("Location: login.php"); exit; }

// Статистика
$count_clients = $pdo->query("SELECT COUNT(*) FROM clients")->fetchColumn();
$count_deals_today = $pdo->query("SELECT COUNT(*) FROM deals WHERE DATE(deal_date) = CURDATE()")->fetchColumn();
$money_today = $pdo->query("SELECT SUM(total_sum) FROM deals WHERE DATE(deal_date) = CURDATE()")->fetchColumn();
?>
<!DOCTYPE html>
<html lang="uk" class="dark">
<head>
    <meta charset="UTF-8">
    <title>Дашборд</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        // Налаштування теми
        tailwind.config = { darkMode: 'class' }
    </script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;800&display=swap" rel="stylesheet">
    <style> body { font-family: 'Inter', sans-serif; } </style>
</head>
<body class="bg-gray-100 dark:bg-slate-900 text-slate-800 dark:text-slate-100 transition-colors duration-300">

<div class="flex h-screen overflow-hidden">
    <aside class="w-64 bg-white dark:bg-slate-800 border-r border-gray-200 dark:border-slate-700 flex flex-col shadow-xl z-10 transition-colors duration-300">
        <div class="h-20 flex items-center justify-center border-b border-gray-200 dark:border-slate-700">
            <h1 class="text-2xl font-extrabold bg-clip-text text-transparent bg-gradient-to-r from-blue-500 to-purple-600">NOTARY CRM</h1>
        </div>
        <nav class="flex-1 px-4 py-6 space-y-2">
            <a href="board.php" class="flex items-center px-4 py-3 bg-blue-600 text-white rounded-xl shadow-lg shadow-blue-500/30 transition transform hover:scale-105">📊 <span class="ml-3 font-semibold">Головна</span></a>
            <a href="kanban.php" class="flex items-center px-4 py-3 text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-slate-700 rounded-xl transition">📋 <span class="ml-3 font-medium">Угоди</span></a>
            <a href="clients.php" class="flex items-center px-4 py-3 text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-slate-700 rounded-xl transition">👥 <span class="ml-3 font-medium">Клієнти</span></a>
            <a href="services.php" class="flex items-center px-4 py-3 text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-slate-700 rounded-xl transition">📝 <span class="ml-3 font-medium">Послуги</span></a>
            <a href="notaries.php" class="flex items-center px-4 py-3 text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-slate-700 rounded-xl transition">⚖️ <span class="ml-3 font-medium">Нотаріуси</span></a>
            <a href="stats.php" class="flex items-center px-4 py-3 text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-slate-700 rounded-xl transition">📈 <span class="ml-3 font-medium">Статистика</span></a>
        </nav>
        <div class="p-4 border-t border-gray-200 dark:border-slate-700">
            <a href="logout.php" class="flex items-center justify-center px-4 py-2 text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-xl transition font-bold">🚪 Вийти</a>
        </div>
    </aside>

    <main class="flex-1 overflow-y-auto relative">
        <header class="h-20 bg-white/80 dark:bg-slate-800/80 backdrop-blur-md border-b border-gray-200 dark:border-slate-700 flex items-center justify-between px-8 sticky top-0 z-20">
            <h2 class="text-xl font-bold">Огляд системи</h2>
            <div class="flex items-center gap-4">
                <div id="clock" class="text-sm font-mono bg-gray-100 dark:bg-slate-700 px-3 py-1 rounded-lg">00:00:00</div>
                <button id="theme-toggle" class="p-2 rounded-lg bg-gray-200 dark:bg-slate-700 hover:bg-gray-300 transition">
                    <span id="sun-icon" class="hidden">☀️</span>
                    <span id="moon-icon">🌙</span>
                </button>
            </div>
        </header>

        <div class="p-8">
            <div class="bg-gradient-to-r from-blue-600 to-purple-600 rounded-3xl p-8 text-white shadow-2xl mb-8 relative overflow-hidden">
                <div class="absolute top-0 right-0 -mt-10 -mr-10 w-40 h-40 bg-white/20 rounded-full blur-3xl"></div>
                <h3 class="text-3xl font-bold mb-2">Привіт, Адмін! 👋</h3>
                <p class="opacity-90">Успішного робочого дня. Сьогодні вже створено <span class="font-bold underline"><?= $count_deals_today ?></span> угод.</p>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <div class="bg-white dark:bg-slate-800 p-6 rounded-2xl shadow-lg border border-gray-100 dark:border-slate-700 hover:shadow-xl transition transform hover:-translate-y-1">
                    <div class="text-gray-500 dark:text-gray-400 text-sm font-medium uppercase mb-1">Клієнтів</div>
                    <div class="text-3xl font-bold text-slate-800 dark:text-white"><?= $count_clients ?></div>
                    <div class="mt-2 text-green-500 text-sm font-bold flex items-center">👥 Активна база</div>
                </div>

                <div class="bg-white dark:bg-slate-800 p-6 rounded-2xl shadow-lg border border-gray-100 dark:border-slate-700 hover:shadow-xl transition transform hover:-translate-y-1">
                    <div class="text-gray-500 dark:text-gray-400 text-sm font-medium uppercase mb-1">Каса сьогодні</div>
                    <div class="text-3xl font-bold text-blue-600 dark:text-blue-400"><?= number_format($money_today, 0, '.', ' ') ?> ₴</div>
                    <div class="mt-2 text-blue-500 text-sm font-bold flex items-center">💰 Прибуток</div>
                </div>

                <div class="bg-white dark:bg-slate-800 p-6 rounded-2xl shadow-lg border border-gray-100 dark:border-slate-700 hover:shadow-xl transition transform hover:-translate-y-1">
                    <div class="text-gray-500 dark:text-gray-400 text-sm font-medium uppercase mb-1">Курс НБУ (USD)</div>
                    <div class="text-3xl font-bold text-green-600 dark:text-green-400" id="usd-rate">...</div>
                    <div class="mt-2 text-gray-400 text-sm">💵 Оновлено</div>
                </div>
            </div>
        </div>
    </main>
</div>

<script>
    // Логіка теми (Темна/Світла)
    const html = document.documentElement;
    const toggleBtn = document.getElementById('theme-toggle');
    const sun = document.getElementById('sun-icon');
    const moon = document.getElementById('moon-icon');

    // Перевірка збереженої теми
    if (localStorage.theme === 'dark' || (!('theme' in localStorage) && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
        html.classList.add('dark');
    } else {
        html.classList.remove('dark');
    }

    function updateIcons() {
        if (html.classList.contains('dark')) {
            sun.classList.remove('hidden');
            moon.classList.add('hidden');
        } else {
            sun.classList.add('hidden');
            moon.classList.remove('hidden');
        }
    }
    updateIcons();

    toggleBtn.addEventListener('click', () => {
        html.classList.toggle('dark');
        localStorage.theme = html.classList.contains('dark') ? 'dark' : 'light';
        updateIcons();
    });

    // Годинник
    setInterval(() => {
        document.getElementById('clock').innerText = new Date().toLocaleTimeString('uk-UA');
    }, 1000);

    // Курс
    fetch('https://bank.gov.ua/NBUStatService/v1/statdirectory/exchange?valcode=USD&json')
        .then(r => r.json())
        .then(d => document.getElementById('usd-rate').innerText = d[0].rate.toFixed(2));
</script>

</body>
</html>
