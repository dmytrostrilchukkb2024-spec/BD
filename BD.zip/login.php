<?php
session_start();
if (isset($_SESSION['admin_auth'])) { header("Location: board.php"); exit; }

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login = $_POST['login']; $pass  = $_POST['password'];
    if ($login === 'DmtStr' && $pass === 'pass123') {
        $_SESSION['admin_auth'] = true; header("Location: board.php"); exit;
    } else { $error = "Невірний логін або пароль"; }
}
?>
<!DOCTYPE html>
<html lang="uk" class="dark">
<head>
    <meta charset="UTF-8">
    <title>Вхід | System CRM</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = { darkMode: 'class', theme: { extend: { animation: { 'gradient': 'gradient 8s ease infinite' }, keyframes: { gradient: { '0%, 100%': { 'background-position': '0% 50%' }, '50%': { 'background-position': '100% 50%' } } } } } }
    </script>
    <style>
        .glass { background: rgba(255, 255, 255, 0.1); backdrop-filter: blur(10px); -webkit-backdrop-filter: blur(10px); border: 1px solid rgba(255, 255, 255, 0.2); }
        .animate-bg { background: linear-gradient(-45deg, #0f172a, #1e293b, #334155, #1e1b4b); background-size: 400% 400%; animation: gradient 10s ease infinite; }
    </style>
</head>
<body class="animate-bg flex items-center justify-center h-screen font-sans">

<div class="glass p-10 rounded-3xl shadow-2xl w-full max-w-md text-center transform transition duration-500 hover:scale-105">
    <div class="text-5xl mb-4">⚖️</div>
    <h2 class="text-3xl font-bold text-white mb-2">CRM Система</h2>
    <p class="text-white/70 mb-8">Вхід для персоналу</p>

    <?php if($error): ?>
        <div class="bg-red-500/80 text-white p-3 rounded-xl mb-4 text-sm font-bold animate-pulse"><?= $error ?></div>
    <?php endif; ?>

    <form method="POST" class="space-y-4">
        <input type="text" name="login" placeholder="Логін" required autocomplete="off"
               class="w-full p-4 rounded-xl bg-white/20 text-white placeholder-white/60 outline-none border border-transparent focus:border-white focus:bg-white/30 transition">

        <input type="text" name="password" placeholder="Пароль" required
               class="w-full p-4 rounded-xl bg-white/20 text-white placeholder-white/60 outline-none border border-transparent focus:border-white focus:bg-white/30 transition">

        <button type="submit"
                class="w-full py-4 rounded-xl bg-white text-slate-900 font-black text-lg shadow-xl hover:bg-blue-500 hover:text-white transition duration-300 transform active:scale-95">
            УВІЙТИ
        </button>
    </form>

    <div class="mt-8 text-white/40 text-xs">
        &copy; <?= date('Y') ?> Notary Office Management System
    </div>
</div>

</body>
</html>
